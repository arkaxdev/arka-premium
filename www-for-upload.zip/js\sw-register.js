// Service Worker Registration
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('ServiceWorker registration successful:', registration.scope);
                
                // Check for updates every hour
                setInterval(() => {
                    registration.update();
                }, 3600000);
                
                // Handle updates
                registration.addEventListener('updatefound', () => {
                    const newWorker = registration.installing;
                    
                    newWorker.addEventListener('statechange', () => {
                        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                            // New content available, show update notification
                            if (confirm('نسخه جدیدی از اپلیکیشن موجود است. آیا می‌خواهید بروزرسانی کنید؟')) {
                                window.location.reload();
                            }
                        }
                    });
                });
            })
            .catch(err => {
                console.log('ServiceWorker registration failed:', err);
            });
    });
    
    // Handle messages from service worker
    navigator.serviceWorker.addEventListener('message', event => {
        console.log('Message from service worker:', event.data);
    });
}

// Request persistent storage
if (navigator.storage && navigator.storage.persist) {
    navigator.storage.persist().then(granted => {
        if (granted) {
            console.log('Persistent storage granted');
        }
    });
}

// Enable background sync
if ('sync' in navigator.serviceWorker) {
    navigator.serviceWorker.ready.then(registration => {
        // Register background sync
        registration.sync.register('sync-products').catch(err => {
            console.log('Background sync registration failed:', err);
        });
    });
}
