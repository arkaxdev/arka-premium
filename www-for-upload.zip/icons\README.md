# Icons Directory

این پوشه حاوی آیکون‌های PWA است.

## آیکون‌های مورد نیاز:

- icon-16x16.png
- icon-32x32.png
- icon-72x72.png
- icon-96x96.png
- icon-128x128.png
- icon-144x144.png
- icon-152x152.png
- icon-180x180.png (برای iOS)
- icon-192x192.png
- icon-384x384.png
- icon-512x512.png

## نحوه تولید آیکون‌ها:

1. فایل `generate-icons.html` را در مرورگر باز کنید
2. روی دکمه "تولید همه آیکون‌ها" کلیک کنید
3. آیکون‌ها را دانلود و در این پوشه قرار دهید

یا از ابزارهای آنلاین مثل:
- https://www.pwabuilder.com/imageGenerator
- https://realfavicongenerator.net/
