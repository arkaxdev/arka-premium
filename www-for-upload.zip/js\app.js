// ARKA PREMIUM PWA - Main App Controller
let deferredPrompt;
let currentPage = 'splash';

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    checkOnlineStatus();
    setupMessageListener();
    setupInstallPrompt();
});

function initializeApp() {
    // Check authentication on startup
    setTimeout(() => {
        checkAuthentication();
    }, 1500);
}

// Check authentication status
async function checkAuthentication() {
    try {
        const token = await getStorageItem('token');
        
        if (token && token.length > 0) {
            navigateTo('home');
        } else {
            navigateTo('login');
        }
    } catch (error) {
        console.error('Auth check error:', error);
        navigateTo('login');
    }
}

// Navigation function
function navigateTo(page) {
    const mainFrame = document.getElementById('mainFrame');
    if (mainFrame) {
        currentPage = page;
        mainFrame.src = `pages/${page}.html`;
        
        // Update theme color based on page
        updateThemeColor(page);
    }
}

// Update theme color
function updateThemeColor(page) {
    const metaThemeColor = document.querySelector('meta[name=theme-color]');
    if (metaThemeColor) {
        switch(page) {
            case 'splash':
                metaThemeColor.setAttribute('content', '#667eea');
                break;
            case 'login':
                metaThemeColor.setAttribute('content', '#f8fafc');
                break;
            case 'home':
                metaThemeColor.setAttribute('content', '#667eea');
                break;
        }
    }
}

// Listen for messages from iframes
function setupMessageListener() {
    window.addEventListener('message', async function(event) {
        // Verify origin for security
        if (event.origin !== window.location.origin) return;
        
        switch(event.data.type) {
            case 'navigate':
                navigateTo(event.data.page);
                break;
                
            case 'storage-set':
                await setStorageItem(event.data.key, event.data.value);
                break;
                
            case 'storage-get':
                const value = await getStorageItem(event.data.key);
                event.source.postMessage({
                    type: 'storage-response',
                    key: event.data.key,
                    value: value
                }, event.origin);
                break;
                
            case 'storage-remove':
                await removeStorageItem(event.data.key);
                break;
                
            case 'storage-clear':
                await clearStorage();
                break;
                
            case 'open-url':
                window.open(event.data.url, '_blank');
                break;
                
            case 'set-cookie':
                // Handle cookie setting for PWA
                await setCookie(event.data.cookie);
                break;
                
            case 'remove-cookie':
                // Handle cookie removal for PWA
                await removeCookie(event.data.name, event.data.url);
                break;
        }
    });
}

// Storage functions using IndexedDB
async function getStorageItem(key) {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('ArkaDB', 1);
        
        request.onerror = () => reject(request.error);
        
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains('storage')) {
                db.createObjectStore('storage', { keyPath: 'key' });
            }
        };
        
        request.onsuccess = (event) => {
            const db = event.target.result;
            const transaction = db.transaction(['storage'], 'readonly');
            const store = transaction.objectStore('storage');
            const getRequest = store.get(key);
            
            getRequest.onsuccess = () => {
                resolve(getRequest.result ? getRequest.result.value : null);
            };
            
            getRequest.onerror = () => reject(getRequest.error);
        };
    });
}

async function setStorageItem(key, value) {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('ArkaDB', 1);
        
        request.onerror = () => reject(request.error);
        
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains('storage')) {
                db.createObjectStore('storage', { keyPath: 'key' });
            }
        };
        
        request.onsuccess = (event) => {
            const db = event.target.result;
            const transaction = db.transaction(['storage'], 'readwrite');
            const store = transaction.objectStore('storage');
            const putRequest = store.put({ key: key, value: value });
            
            putRequest.onsuccess = () => resolve();
            putRequest.onerror = () => reject(putRequest.error);
        };
    });
}

async function removeStorageItem(key) {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('ArkaDB', 1);
        
        request.onerror = () => reject(request.error);
        
        request.onsuccess = (event) => {
            const db = event.target.result;
            const transaction = db.transaction(['storage'], 'readwrite');
            const store = transaction.objectStore('storage');
            const deleteRequest = store.delete(key);
            
            deleteRequest.onsuccess = () => resolve();
            deleteRequest.onerror = () => reject(deleteRequest.error);
        };
    });
}

async function clearStorage() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('ArkaDB', 1);
        
        request.onerror = () => reject(request.error);
        
        request.onsuccess = (event) => {
            const db = event.target.result;
            const transaction = db.transaction(['storage'], 'readwrite');
            const store = transaction.objectStore('storage');
            const clearRequest = store.clear();
            
            clearRequest.onsuccess = () => resolve();
            clearRequest.onerror = () => reject(clearRequest.error);
        };
    });
}

// Cookie management for PWA
async function setCookie(cookieData) {
    // In PWA, we'll store cookies in IndexedDB
    const cookies = await getStorageItem('cookies') || {};
    const domain = cookieData.domain || cookieData.url;
    
    if (!cookies[domain]) {
        cookies[domain] = [];
    }
    
    // Remove existing cookie with same name
    cookies[domain] = cookies[domain].filter(c => c.name !== cookieData.name);
    
    // Add new cookie
    cookies[domain].push(cookieData);
    
    await setStorageItem('cookies', cookies);
}

async function removeCookie(name, url) {
    const cookies = await getStorageItem('cookies') || {};
    const domain = new URL(url).hostname;
    
    if (cookies[domain]) {
        cookies[domain] = cookies[domain].filter(c => c.name !== name);
        await setStorageItem('cookies', cookies);
    }
}

// Online/Offline status
function checkOnlineStatus() {
    const offlineMessage = document.getElementById('offlineMessage');
    
    function updateOnlineStatus() {
        if (navigator.onLine) {
            offlineMessage.style.display = 'none';
        } else {
            offlineMessage.style.display = 'block';
        }
    }
    
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    
    updateOnlineStatus();
}

// Install prompt
function setupInstallPrompt() {
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        
        // Show install prompt after 30 seconds
        setTimeout(() => {
            showInstallPrompt();
        }, 30000);
    });
    
    window.addEventListener('appinstalled', () => {
        console.log('ARKA PREMIUM installed');
        hideInstallPrompt();
    });
}

function showInstallPrompt() {
    const installPrompt = document.getElementById('installPrompt');
    if (installPrompt && deferredPrompt) {
        installPrompt.style.display = 'block';
    }
}

function hideInstallPrompt() {
    const installPrompt = document.getElementById('installPrompt');
    if (installPrompt) {
        installPrompt.style.display = 'none';
    }
}

async function installApp() {
    hideInstallPrompt();
    
    if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        
        if (outcome === 'accepted') {
            console.log('User accepted install prompt');
        } else {
            console.log('User dismissed install prompt');
        }
        
        deferredPrompt = null;
    }
}

// Make functions available globally
window.navigateTo = navigateTo;
window.hideInstallPrompt = hideInstallPrompt;
window.installApp = installApp;
