// ARKA PREMIUM PWA - Home Page Controller
let apiBase = 'https://api.divateam.co/api';
let products = [];
let connectedProducts = new Set();

// Initialize page
document.addEventListener('DOMContentLoaded', async () => {
    await checkAuthentication();
    await loadProducts();
    setupEventListeners();
    loadConnectedProducts();
});

// Check authentication
async function checkAuthentication() {
    const token = await getStorageItem('token');
    if (!token) {
        window.parent.postMessage({ type: 'navigate', page: 'login' }, '*');
        return false;
    }
    return true;
}

// Load products
async function loadProducts() {
    const progressEl = document.getElementById('progress');
    const emptyState = document.getElementById('emptyState');
    
    progressEl.classList.add('show');
    emptyState.style.display = 'none';
    
    try {
        // First try to load from cache
        const cachedProducts = await getStorageItem('products');
        if (cachedProducts) {
            products = JSON.parse(cachedProducts);
            displayProducts(products);
        }
        
        // Then fetch fresh data
        const token = await getStorageItem('token');
        const response = await fetch(apiBase + '/v1/profile/products', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        });
        
        if (!response.ok) {
            if (response.status === 403) {
                await logout();
                return;
            }
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        products = data;
        
        // Save to cache
        await setStorageItem('products', JSON.stringify(data));
        
        if (data && data.length > 0) {
            displayProducts(data);
        } else {
            showEmptyState();
        }
        
    } catch (error) {
        console.error('Load products error:', error);
        showToast('خطا در بارگذاری محصولات: ' + error.message, 5000);
        
        // If we have cached products, show them
        if (products.length > 0) {
            displayProducts(products);
        } else {
            showEmptyState();
        }
    } finally {
        progressEl.classList.remove('show');
    }
}

// Display products
function displayProducts(products) {
    const container = document.getElementById('product_list');
    const emptyState = document.getElementById('emptyState');
    
    container.innerHTML = '';
    emptyState.style.display = 'none';
    
    if (!products || products.length === 0) {
        showEmptyState();
        return;
    }
    
    products.forEach(product => {
        const productEl = createProductElement(product);
        container.appendChild(productEl);
    });
}

// Create product element
function createProductElement(product) {
    const div = document.createElement('div');
    div.id = `product-${product.id}`;
    div.className = 'product';
    
    const isConnected = connectedProducts.has(product.id);
    const logoUrl = product.product.logo || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTYiIGhlaWdodD0iNTYiIHZpZXdCb3g9IjAgMCA1NiA1NiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjU2IiBoZWlnaHQ9IjU2IiByeD0iMTQiIGZpbGw9IiM2NjdlZWEiLz4KPHRleHQgeD0iMjgiIHk9IjM2IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMjQiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSI+QTwvdGV4dD4KPC9zdmc+';
    
    let html = `
        <div class="section">
            <div class="logo">
                <a href="#" onclick="openUrl('${product.product.url}'); return false;">
                    <img src="${logoUrl}" alt="logo" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTYiIGhlaWdodD0iNTYiIHZpZXdCb3g9IjAgMCA1NiA1NiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjU2IiBoZWlnaHQ9IjU2IiByeD0iMTQiIGZpbGw9IiM2NjdlZWEiLz4KPHRleHQgeD0iMjgiIHk9IjM2IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMjQiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSI+QTwvdGV4dD4KPC9zdmc+'"/>
                    <div class="info">
                        <p class="name">${product.product.name}</p>
                        <p class="expire">انقضا: ${product.end_date || 'نامشخص'}</p>
                    </div>
                </a>
            </div>
        </div>
    `;
    
    if (product.type === 'INVITABLE') {
        if (product.invited === true) {
            html += `
                <div class="status">
                    <p class="joined">✅ عضو شده</p>
                </div>
            `;
        } else {
            html += `
                <div class="status">
                    <button class="connect-btn" onclick="handleConnect('${product.id}')">🚀 CONNECT</button>
                    <button class="details-btn" onclick="showProductDetails('${product.id}')">📋 جزئیات</button>
                </div>
            `;
        }
    } else {
        html += `
            <div class="status">
                <button class="connect-btn ${isConnected ? 'connected' : ''}" id="connect-${product.id}" onclick="handleConnect('${product.id}')">
                    ${isConnected ? '🔴 DISCONNECT' : '🚀 CONNECT'}
                </button>
                <button class="details-btn" onclick="showProductDetails('${product.id}')">📋 جزئیات</button>
            </div>
        `;
    }
    
    div.innerHTML = html;
    return div;
}

// Handle connect/disconnect
async function handleConnect(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const isConnected = connectedProducts.has(productId);
    const connectBtn = document.getElementById(`connect-${productId}`);
    
    if (connectBtn) {
        connectBtn.disabled = true;
        connectBtn.textContent = isConnected ? '🔄 در حال قطع...' : '🔄 در حال اتصال...';
    }
    
    try {
        if (isConnected) {
            await disconnectProduct(product);
            connectedProducts.delete(productId);
            showToast('🔴 محصول قطع شد', 3000);
        } else {
            await connectProduct(product);
            connectedProducts.add(productId);
            showToast('✅ محصول با موفقیت متصل شد!', 3000);
            
            // Open the website after successful connection
            setTimeout(() => {
                openUrl(product.product.url);
            }, 1000);
        }
        
        // Update button state
        if (connectBtn) {
            connectBtn.classList.toggle('connected');
            connectBtn.textContent = connectedProducts.has(productId) ? '🔴 DISCONNECT' : '🚀 CONNECT';
            connectBtn.disabled = false;
        }
        
        // Save connected products
        await saveConnectedProducts();
        
    } catch (error) {
        console.error('Connection error:', error);
        showToast('خطا: ' + error.message, 3000);
        
        if (connectBtn) {
            connectBtn.disabled = false;
            connectBtn.textContent = isConnected ? '🔴 DISCONNECT' : '🚀 CONNECT';
        }
    }
}

// Connect product
async function connectProduct(product) {
    const hasCookies = product.product.cookies && product.product.cookies.length > 0;
    const hasStorages = product.product.storages && product.product.storages.length > 0;
    
    if (!hasCookies && !hasStorages) {
        throw new Error('محصول منقضی شده است');
    }
    
    // Save cookies
    if (hasCookies) {
        const cookies = JSON.parse(product.product.cookies);
        await setStorageItem(`cookies_${product.id}`, JSON.stringify(cookies));
        
        // Send message to parent to set cookies
        window.parent.postMessage({
            type: 'set-cookie',
            cookie: {
                productId: product.id,
                url: product.product.url,
                cookies: cookies
            }
        }, '*');
    }
    
    // Save storage data
    if (hasStorages) {
        await setStorageItem(`storage_${product.id}`, JSON.stringify(product.product.storages));
    }
    
    // Send analytics
    sendAnalytics(product.id, 'activate');
}

// Disconnect product
async function disconnectProduct(product) {
    // Remove cookies
    await removeStorageItem(`cookies_${product.id}`);
    
    // Send message to parent to remove cookies
    window.parent.postMessage({
        type: 'remove-cookie',
        name: product.id,
        url: product.product.url
    }, '*');
    
    // Remove storage data
    await removeStorageItem(`storage_${product.id}`);
    
    // Send analytics
    sendAnalytics(product.id, 'deactivate');
}

// Show product details
function showProductDetails(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const template = document.getElementById('modalTemplate');
    const modal = template.content.cloneNode(true);
    
    const cookiesCount = product.product.cookies ? JSON.parse(product.product.cookies).length : 0;
    const storagesCount = product.product.storages ? product.product.storages.length : 0;
    
    const modalBody = modal.querySelector('.modal-body');
    modalBody.innerHTML = `
        <div class="detail-item">
            <strong>🌐 وب‌سایت:</strong>
            <span>${product.product.url}</span>
        </div>
        <div class="detail-item">
            <strong>🍪 کوکی‌ها:</strong>
            <span>${cookiesCount} مورد</span>
        </div>
        <div class="detail-item">
            <strong>💾 داده‌های ذخیره:</strong>
            <span>${storagesCount} مورد</span>
        </div>
        <div class="detail-item">
            <strong>🔒 دامنه:</strong>
            <span>${product.product.domain}</span>
        </div>
        <div class="detail-item">
            <strong>📅 انقضا:</strong>
            <span>${product.end_date || 'نامشخص'}</span>
        </div>
        <div class="detail-item">
            <strong>🏷️ نوع:</strong>
            <span>${product.type === 'INVITABLE' ? 'دعوتی' : 'عادی'}</span>
        </div>
        ${product.product.restricts ? `
        <div class="detail-item">
            <strong>🚫 محدودیت‌ها:</strong>
            <span>${product.product.restricts}</span>
        </div>
        ` : ''}
    `;
    
    document.body.appendChild(modal);
    
    const modalEl = document.querySelector('.details-modal');
    const closeBtn = modalEl.querySelector('.close-btn');
    const closeModalBtn = modalEl.querySelector('#closeModalBtn');
    const openSiteBtn = modalEl.querySelector('#openSiteBtn');
    
    closeBtn.onclick = () => modalEl.remove();
    closeModalBtn.onclick = () => modalEl.remove();
    openSiteBtn.onclick = () => {
        openUrl(product.product.url);
        modalEl.remove();
    };
    
    modalEl.onclick = (e) => {
        if (e.target === modalEl) modalEl.remove();
    };
}

// Setup event listeners
function setupEventListeners() {
    // Refresh button
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            refreshBtn.disabled = true;
            refreshBtn.innerHTML = '<span class="btn-icon">🔄</span><span class="btn-text">در حال بروزرسانی...</span>';
            
            try {
                await removeStorageItem('products');
                await loadProducts();
            } catch (error) {
                console.error('Refresh error:', error);
                showToast('خطا در بروزرسانی', 3000);
            } finally {
                refreshBtn.disabled = false;
                refreshBtn.innerHTML = '<span class="btn-icon">🔄</span><span class="btn-text">بروزرسانی</span>';
            }
        });
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            if (confirm('آیا مطمئن هستید که می‌خواهید خروج کنید؟')) {
                await logout();
            }
        });
    }
}

// Helper functions
async function getStorageItem(key) {
    return new Promise((resolve) => {
        window.parent.postMessage({ type: 'storage-get', key: key }, '*');
        
        const handler = (event) => {
            if (event.data.type === 'storage-response' && event.data.key === key) {
                window.removeEventListener('message', handler);
                resolve(event.data.value);
            }
        };
        
        window.addEventListener('message', handler);
        
        // Timeout after 5 seconds
        setTimeout(() => {
            window.removeEventListener('message', handler);
            resolve(null);
        }, 5000);
    });
}

async function setStorageItem(key, value) {
    window.parent.postMessage({ type: 'storage-set', key: key, value: value }, '*');
}

async function removeStorageItem(key) {
    window.parent.postMessage({ type: 'storage-remove', key: key }, '*');
}

async function logout() {
    window.parent.postMessage({ type: 'storage-clear' }, '*');
    window.parent.postMessage({ type: 'navigate', page: 'login' }, '*');
}

function showEmptyState() {
    const emptyState = document.getElementById('emptyState');
    emptyState.style.display = 'block';
}

function showToast(message, duration = 3000) {
    const toast = document.getElementById('toast');
    if (toast) {
        toast.textContent = message;
        toast.classList.add('toast-show');
        toast.classList.remove('toast-hide');
        
        setTimeout(() => {
            toast.classList.add('toast-hide');
            toast.classList.remove('toast-show');
        }, duration);
    }
}

function openUrl(url) {
    window.parent.postMessage({ type: 'open-url', url: url }, '*');
}

async function sendAnalytics(productId, type) {
    try {
        const token = await getStorageItem('token');
        if (token) {
            fetch(apiBase + '/v1/profile/products/' + productId + '/events', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({ type: type })
            }).catch(error => {
                console.warn('Analytics error:', error);
            });
        }
    } catch (error) {
        console.warn('Analytics error:', error);
    }
}

async function loadConnectedProducts() {
    const saved = await getStorageItem('connectedProducts');
    if (saved) {
        connectedProducts = new Set(JSON.parse(saved));
    }
}

async function saveConnectedProducts() {
    await setStorageItem('connectedProducts', JSON.stringify(Array.from(connectedProducts)));
}

// Make functions available globally
window.handleConnect = handleConnect;
window.showProductDetails = showProductDetails;
window.openUrl = openUrl;
