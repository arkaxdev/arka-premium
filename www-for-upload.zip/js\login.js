// ARKA PREMIUM PWA - Login Controller
const apiBase = 'https://api.divateam.co/api';

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const loginBtn = document.getElementById('loginBtn');
    const errorMessage = document.getElementById('errorMessage');
    
    // Handle form submission
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();
        
        if (!username || !password) {
            showError('لطفاً نام کاربری و رمز عبور را وارد کنید');
            return;
        }
        
        await performLogin(username, password);
    });
    
    // Auto-focus on username field
    document.getElementById('username').focus();
});

async function performLogin(username, password) {
    const loginBtn = document.getElementById('loginBtn');
    const errorMessage = document.getElementById('errorMessage');
    
    // Show loading state
    loginBtn.disabled = true;
    loginBtn.classList.add('loading');
    loginBtn.textContent = '';
    hideError();
    
    // Check for test credentials first
    if (username === 'ParsPremiummidjourney463' && password === 'ParsPremium:1404') {
        // Simulate successful login for test user
        const mockData = {
            token: 'test_token_' + Date.now(),
            user: {
                username: username,
                email: 'parspremium@example.com',
                name: 'Pars Premium User'
            }
        };
        
        // Save token and user data
        await saveLoginData(mockData);
        
        // Show success feedback
        loginBtn.classList.remove('loading');
        loginBtn.textContent = '✓ ورود موفق';
        loginBtn.style.background = 'linear-gradient(135deg, #48bb78 0%, #38a169 100%)';
        
        // Navigate to home after a short delay
        setTimeout(() => {
            window.parent.postMessage({ type: 'navigate', page: 'home' }, '*');
        }, 500);
        
        return;
    }
    
    // Otherwise, try real API
    try {
        const response = await fetch(apiBase + '/v1/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });
        
        const data = await response.json();
        
        if (response.ok && data.token) {
            // Save token and user data
            await saveLoginData(data);
            
            // Show success feedback
            loginBtn.classList.remove('loading');
            loginBtn.textContent = '✓ ورود موفق';
            loginBtn.style.background = 'linear-gradient(135deg, #48bb78 0%, #38a169 100%)';
            
            // Navigate to home after a short delay
            setTimeout(() => {
                window.parent.postMessage({ type: 'navigate', page: 'home' }, '*');
            }, 500);
            
        } else {
            throw new Error(data.message || 'خطا در ورود به حساب');
        }
        
    } catch (error) {
        console.error('Login error:', error);
        
        // Reset button state
        loginBtn.disabled = false;
        loginBtn.classList.remove('loading');
        loginBtn.textContent = 'ورود';
        
        // Show error message
        if (error.message.includes('fetch')) {
            showError('خطا در اتصال به سرور. لطفاً اتصال اینترنت خود را بررسی کنید');
        } else {
            showError(error.message || 'خطا در ورود. لطفاً دوباره تلاش کنید');
        }
    }
}

async function saveLoginData(data) {
    // Send message to parent to save data
    window.parent.postMessage({
        type: 'storage-set',
        key: 'token',
        value: data.token
    }, '*');
    
    if (data.user) {
        window.parent.postMessage({
            type: 'storage-set',
            key: 'user',
            value: JSON.stringify(data.user)
        }, '*');
    }
    
    // Wait a bit to ensure data is saved
    await new Promise(resolve => setTimeout(resolve, 100));
}

function showError(message) {
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.textContent = message;
    errorMessage.classList.add('show');
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        hideError();
    }, 5000);
}

function hideError() {
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.classList.remove('show');
}

// Handle Enter key in inputs
document.getElementById('username').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        document.getElementById('password').focus();
    }
});

// Handle offline/online status
window.addEventListener('online', () => {
    hideError();
});

window.addEventListener('offline', () => {
    showError('اتصال اینترنت قطع شده است');
});

// Prevent form resubmission on page refresh
if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
}
