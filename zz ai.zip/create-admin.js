const { PrismaClient } = require('@prisma/client')
const bcrypt = require('bcryptjs')

const prisma = new PrismaClient()

async function main() {
  try {
    // Check if admin exists
    const existingAdmin = await prisma.user.findUnique({
      where: { email: 'admin@example.com' }
    })

    if (existingAdmin) {
      console.log('Admin user already exists')
      
      // Update to ensure it's an admin
      const updated = await prisma.user.update({
        where: { email: 'admin@example.com' },
        data: {
          role: 'ADMIN',
          password: await bcrypt.hash('admin123', 10),
          name: 'مدیر سیستم',
          emailVerified: true,
          isActive: true
        }
      })
      
      console.log('Admin user updated:', updated)
    } else {
      // Create new admin
      const hashedPassword = await bcrypt.hash('admin123', 10)
      
      const admin = await prisma.user.create({
        data: {
          email: 'admin@example.com',
          password: hashedPassword,
          name: 'مدیر سیستم',
          role: 'ADMIN',
          emailVerified: true,
          isActive: true
        }
      })
      
      console.log('Admin user created:', admin)
    }
  } catch (error) {
    console.error('Error:', error)
  } finally {
    await prisma.$disconnect()
  }
}

main()
