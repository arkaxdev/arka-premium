# LinkFlow - Professional URL Shortener

![LinkFlow](https://img.shields.io/badge/LinkFlow-URL%20Shortener-blue?style=for-the-badge&logo=link&logoColor=white)
![Version](https://img.shields.io/badge/version-1.0.0-green?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-purple?style=for-the-badge)

**LinkFlow** is a modern, intelligent, and beautiful URL shortening service built with Next.js 15, TypeScript, and Tailwind CSS. It offers advanced analytics, custom aliases, QR code generation, and a premium VIP system.

## ✨ Features

### 🚀 Core Features
- **Lightning Fast URL Shortening** - Instant redirection with global CDN
- **Custom Aliases** - Create memorable, branded short links
- **Advanced Analytics** - Real-time statistics with detailed insights
- **QR Code Generation** - Generate and download QR codes for any link
- **Password Protection** - Secure your links with passwords
- **Link Expiration** - Set expiration dates for temporary links
- **Click Limits** - Limit the number of clicks for your links
- **Ad Management** - Monetize your links with interstitial ads

### 👤 User Features
- **User Authentication** - Sign up with email or Google
- **User Profiles** - Custom profile pages at `/u/username`
- **Dashboard** - Comprehensive link management interface
- **Social Integration** - Connect social media accounts
- **VIP System** - Premium features for paid users

### 📊 Analytics & Insights
- **Real-time Statistics** - Live click tracking
- **Geographic Data** - Visitor location tracking
- **Device & Browser Info** - Detailed visitor analytics
- **Referral Tracking** - Know where your traffic comes from
- **Export Data** - Download analytics reports

### 🎨 Design & UX
- **Modern UI/UX** - Beautiful, intuitive interface
- **Dark/Light Theme** - Toggle between themes
- **Responsive Design** - Perfect on all devices
- **Smooth Animations** - Engaging micro-interactions
- **Glassmorphism Effects** - Modern frosted glass design

### 🔧 Technical Features
- **RESTful API** - Complete API for developers
- **Webhook Support** - Real-time notifications
- **Rate Limiting** - Protect against abuse
- **Security** - Enterprise-grade protection
- **Scalable** - Built for high traffic

## 🛠️ Tech Stack

### Frontend
- **Next.js 15** - React framework with App Router
- **TypeScript** - Type-safe JavaScript
- **Tailwind CSS 4** - Utility-first CSS framework
- **shadcn/ui** - Modern UI component library
- **Framer Motion** - Production-ready motion library
- **NextAuth.js** - Authentication for Next.js
- **Zustand** - Lightweight state management
- **TanStack Query** - Server-state management

### Backend
- **Node.js** - JavaScript runtime
- **Prisma** - Next-generation ORM
- **SQLite** - Lightweight database
- **bcryptjs** - Password hashing
- **nanoid** - Tiny, secure URL-friendly string generator
- **qrcode** - QR code generation

### Infrastructure
- **Vercel Ready** - Deploy with one click
- **Docker Support** - Containerized deployment
- **Environment Config** - Easy configuration

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/linkflow.git
   cd linkflow
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` with your configuration:
   ```env
   DATABASE_URL=file:./dev.db
   NEXTAUTH_URL=http://localhost:3000
   NEXTAUTH_SECRET=your-super-secret-key
   GOOGLE_CLIENT_ID=your-google-client-id
   GOOGLE_CLIENT_SECRET=your-google-client-secret
   NEXT_PUBLIC_BASE_URL=http://localhost:3000
   ```

4. **Set up the database**
   ```bash
   npm run db:push
   npm run db:generate
   ```

5. **Start the development server**
   ```bash
   npm run dev
   ```

6. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## 📁 Project Structure

```
linkflow/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── api/               # API routes
│   │   ├── auth/              # Authentication pages
│   │   ├── dashboard/         # User dashboard
│   │   ├── admin/             # Admin panel
│   │   ├── u/[username]/      # User profiles
│   │   ├── ads/[code]/       # Ad interstitial
│   │   ├── [code]/           # Link redirection
│   │   ├── vip/              # VIP page
│   │   ├── globals.css       # Global styles
│   │   ├── layout.tsx        # Root layout
│   │   └── page.tsx          # Homepage
│   ├── components/            # React components
│   │   ├── ui/               # shadcn/ui components
│   │   ├── providers/        # Context providers
│   │   └── theme-toggle.tsx  # Theme toggle
│   ├── hooks/                # Custom React hooks
│   ├── lib/                  # Utility functions
│   │   ├── auth/             # Auth configuration
│   │   ├── db.ts            # Database client
│   │   └── utils.ts          # Helper functions
│   └── types/               # TypeScript definitions
├── prisma/                   # Database schema
├── public/                   # Static assets
├── .env.example             # Environment template
├── tailwind.config.ts       # Tailwind config
├── package.json             # Dependencies
└── README.md               # This file
```

## 🔧 API Documentation

### Authentication Endpoints

#### Sign In
```http
POST /api/auth/signin
```

#### Sign Up
```http
POST /api/auth/register
```

#### Get Session
```http
GET /api/auth/session
```

### URL Shortening Endpoints

#### Create Short Link
```http
POST /api/shorten
Content-Type: application/json

{
  "url": "https://example.com",
  "customSlug": "my-link",
  "title": "My Link",
  "description": "Link description",
  "password": "optional-password",
  "expiresAt": "2024-12-31T23:59:59Z",
  "maxClicks": 100,
  "showAds": true
}
```

#### Get User Links
```http
GET /api/links
Authorization: Bearer <token>
```

#### Delete Link
```http
DELETE /api/links/{id}
Authorization: Bearer <token>
```

### Analytics Endpoints

#### Get Link Stats
```http
GET /api/links/{id}/stats
Authorization: Bearer <token>
```

#### Track Click
```http
GET /api/redirect/{code}
```

### QR Code Endpoints

#### Generate QR Code
```http
GET /api/qr/{code}?color=000000&background=FFFFFF
```

### User Profile Endpoints

#### Get User Profile
```http
GET /api/users/{username}
```

#### Update Profile
```http
PATCH /api/users/profile
Authorization: Bearer <token>
```

### Admin Endpoints

#### Get All Users
```http
GET /api/admin/users
Authorization: Bearer <admin-token>
```

#### Get System Stats
```http
GET /api/admin/stats
Authorization: Bearer <admin-token>
```

## 🎨 Customization

### Branding
Update the branding in `src/app/layout.tsx`:
```typescript
export const metadata: Metadata = {
  title: "Your App Name",
  description: "Your app description",
  // ... other metadata
}
```

### Colors
Modify the color scheme in `tailwind.config.ts`:
```typescript
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f9ff',
          // ... add your custom colors
        }
      }
    }
  }
}
```

### Logo
Replace the logo in `public/logo.svg` with your own branding.

## 🚀 Deployment

### Vercel (Recommended)
1. Push your code to GitHub
2. Connect your repository to Vercel
3. Add environment variables
4. Deploy with one click

### Docker
```bash
# Build the image
docker build -t linkflow .

# Run the container
docker run -p 3000:3000 linkflow
```

### Manual Deployment
```bash
# Build the application
npm run build

# Start the production server
npm start
```

## 🔐 Security Features

- **Password Hashing** - All passwords are hashed with bcrypt
- **JWT Authentication** - Secure token-based authentication
- **Rate Limiting** - Protect against brute force attacks
- **Input Validation** - All inputs are validated and sanitized
- **CORS Protection** - Cross-origin resource sharing configured
- **HTTPS Only** - Production requires secure connections
- **Environment Variables** - Sensitive data stored securely

## 📈 Performance

- **Lazy Loading** - Components loaded on demand
- **Image Optimization** - Automatic image optimization
- **Code Splitting** - Bundles split for faster loading
- **Caching** - Strategic caching for better performance
- **CDN Ready** - Asset delivery via CDN
- **Database Optimization** - Indexed queries for fast responses

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines
- Follow the existing code style
- Write tests for new features
- Update documentation as needed
- Use TypeScript for type safety
- Follow accessibility best practices

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Next.js Team** - For the amazing framework
- **Tailwind CSS** - For the utility-first CSS framework
- **shadcn/ui** - For the beautiful UI components
- **Prisma** - For the modern ORM
- **All Contributors** - Who helped make this project better

## 📞 Support

- **Documentation**: [docs.linkflow.app](https://docs.linkflow.app)
- **Issues**: [GitHub Issues](https://github.com/your-username/linkflow/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-username/linkflow/discussions)
- **Email**: [support@linkflow.app](mailto:support@linkflow.app)

## 🚀 Roadmap

### Upcoming Features
- [ ] **Mobile Apps** - iOS and Android applications
- [ ] **Browser Extensions** - Chrome and Firefox extensions
- [ ] **Team Collaboration** - Multi-user workspaces
- [ ] **Advanced Analytics** - Machine learning insights
- [ ] **Custom Domains** - White-label solutions
- [ ] **Webhooks** - Real-time notifications
- [ ] **API Rate Limits** - Tiered API access
- [ ] **Link Groups** - Organize links in folders
- [ ] **A/B Testing** - Test different destinations
- [ ] **UTM Builder** - Campaign tracking parameters

---

Made with ❤️ by the LinkFlow Team