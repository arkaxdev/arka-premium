"use client"

import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

export default function TestButtonPage() {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-foreground">Button Test Page</h1>
          <ThemeToggle />
        </div>
        
        <div className="space-y-8">
          <div>
            <h2 className="text-lg font-semibold mb-4 text-foreground">Destructive Button Variants</h2>
            <div className="flex flex-wrap gap-4">
              <Button variant="destructive" size="default">
                Default Destructive
              </Button>
              <Button variant="destructive" size="sm">
                Small Destructive
              </Button>
              <Button variant="destructive" size="lg">
                Large Destructive
              </Button>
            </div>
          </div>
          
          <div>
            <h2 className="text-lg font-semibold mb-4 text-foreground">Button States</h2>
            <div className="flex flex-wrap gap-4">
              <Button variant="destructive" disabled>
                Disabled Destructive
              </Button>
              <Button variant="destructive" className="opacity-80">
                Hover State (simulated)
              </Button>
            </div>
          </div>
          
          <div>
            <h2 className="text-lg font-semibold mb-4 text-foreground">Comparison with Default</h2>
            <div className="flex flex-wrap gap-4">
              <Button variant="default">
                Default Button
              </Button>
              <Button variant="destructive">
                Destructive Button
              </Button>
              <Button variant="outline">
                Outline Button
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}