"use client"

import { useSession, signIn, signOut } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Link2, User, BarChart3, LogOut } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

export default function TestAuthFlowPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const handleSignIn = () => {
    signIn()
  }

  const handleSignOut = () => {
    signOut({ callbackUrl: "/" })
  }

  const goToDashboard = () => {
    router.push("/dashboard")
  }

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-transparent border-t-primary rounded-full mx-auto animate-spin"></div>
          <p className="mt-4 text-muted-foreground">Loading authentication status...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Link2 className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-2xl font-bold text-foreground">Auth Flow Test</h1>
                <p className="text-xs text-muted-foreground">Testing authentication redirect</p>
              </div>
              <div className="sm:hidden">
                <h1 className="text-xl font-bold text-foreground">Auth Test</h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 sm:space-x-4">
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 md:py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Authentication Flow Test
            </h1>
            <p className="text-lg text-muted-foreground">
              Test the authentication and redirect functionality
            </p>
          </div>

          {/* Authentication Status */}
          <Card className="bg-card border-border shadow-sm mb-8">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-foreground">
                Authentication Status
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                Current authentication state and user information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <span className={`font-medium ${status === "authenticated" ? "text-green-600" : status === "loading" ? "text-yellow-600" : "text-red-600"}`}>
                    {status}
                  </span>
                </div>
                
                {session && (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">User ID:</span>
                      <span className="font-medium text-foreground">{session.user?.id}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Email:</span>
                      <span className="font-medium text-foreground">{session.user?.email}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Name:</span>
                      <span className="font-medium text-foreground">{session.user?.name}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Username:</span>
                      <span className="font-medium text-foreground">{session.user?.username}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Role:</span>
                      <span className="font-medium text-foreground">{session.user?.role}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">VIP Status:</span>
                      <span className="font-medium text-foreground">{session.user?.isVIP ? "VIP" : "Free"}</span>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="grid md:grid-cols-2 gap-6">
            {status === "authenticated" ? (
              <>
                <Card className="bg-card border-border shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-xl font-bold text-foreground flex items-center">
                      <BarChart3 className="h-5 w-5 mr-2" />
                      Dashboard Access
                    </CardTitle>
                    <CardDescription className="text-muted-foreground">
                      Go to your dashboard to manage your links
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      onClick={goToDashboard}
                      className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                    >
                      Go to Dashboard
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-xl font-bold text-foreground flex items-center">
                      <LogOut className="h-5 w-5 mr-2" />
                      Sign Out
                    </CardTitle>
                    <CardDescription className="text-muted-foreground">
                      Sign out from your account
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      onClick={handleSignOut}
                      variant="destructive"
                      className="w-full font-semibold"
                    >
                      Sign Out
                    </Button>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="bg-card border-border shadow-sm">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-foreground flex items-center">
                    <User className="h-5 w-5 mr-2" />
                    Sign In
                  </CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Sign in to your account to access the dashboard
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={handleSignIn}
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                  >
                    Sign In
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Test Instructions */}
          <Card className="mt-8 bg-card border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-foreground">
                Test Instructions
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                How to test the authentication flow
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-muted-foreground">
                <p>1. If you're not authenticated, click "Sign In" to test the login flow</p>
                <p>2. After successful login, you should be automatically redirected to the dashboard</p>
                <p>3. If you encounter any redirect loops, check the browser console for errors</p>
                <p>4. The main page should redirect authenticated users to /dashboard</p>
                <p>5. The dashboard should check authentication and redirect to /auth/signin if not authenticated</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}