"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Loader2, AlertCircle, CheckCircle } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function RedirectPage({ params }: { params: { code: string } }) {
  const router = useRouter()
  const [status, setStatus] = useState<"loading" | "redirecting" | "error" | "expired" | "maxClicks">("loading")
  const [errorMessage, setErrorMessage] = useState("")
  const [countdown, setCountdown] = useState(3)

  useEffect(() => {
    const redirect = async () => {
      try {
        const response = await fetch(`/api/redirect/${params.code}`)
        
        if (response.redirected) {
          setStatus("redirecting")
          // Start countdown
          const timer = setInterval(() => {
            setCountdown((prev) => {
              if (prev <= 1) {
                clearInterval(timer)
                window.location.href = response.url
                return 0
              }
              return prev - 1
            })
          }, 1000)
        } else {
          const data = await response.json()
          
          if (response.status === 404) {
            setStatus("error")
            setErrorMessage("Link not found")
          } else if (response.status === 410) {
            if (data.error === "Link has expired") {
              setStatus("expired")
              setErrorMessage("This link has expired")
            } else if (data.error === "Link has reached maximum clicks") {
              setStatus("maxClicks")
              setErrorMessage("This link has reached the maximum number of allowed clicks")
            }
          } else if (data.redirect) {
            // Redirect to ads page
            window.location.href = data.redirect
          } else {
            setStatus("error")
            setErrorMessage("An error occurred during redirect")
          }
        }
      } catch (error) {
        setStatus("error")
        setErrorMessage("Error connecting to server")
      }
    }

    redirect()
  }, [params.code])

  const renderContent = () => {
    switch (status) {
      case "loading":
        return (
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-blue-500" />
            <h2 className="text-xl font-semibold mb-2">Checking link...</h2>
            <p className="text-gray-400">Please wait a moment</p>
          </div>
        )
      
      case "redirecting":
        return (
          <div className="text-center">
            <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-500" />
            <h2 className="text-xl font-semibold mb-2">Redirecting to destination...</h2>
            <p className="text-gray-400 mb-4">
              If you are not redirected automatically, click in {countdown} seconds
            </p>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-1000"
                style={{ width: `${(countdown / 3) * 100}%` }}
              />
            </div>
          </div>
        )
      
      case "error":
        return (
          <div className="text-center">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-red-500" />
            <h2 className="text-xl font-semibold mb-2">Error</h2>
            <p className="text-gray-400">{errorMessage}</p>
          </div>
        )
      
      case "expired":
        return (
          <div className="text-center">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-orange-500" />
            <h2 className="text-xl font-semibold mb-2">Link Expired</h2>
            <p className="text-gray-400">{errorMessage}</p>
          </div>
        )
      
      case "maxClicks":
        return (
          <div className="text-center">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-orange-500" />
            <h2 className="text-xl font-semibold mb-2">Click Limit Reached</h2>
            <p className="text-gray-400">{errorMessage}</p>
          </div>
        )
      
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-800/50 backdrop-blur-sm border-gray-700">
        <CardContent className="p-8">
          {renderContent()}
          
          {(status === "error" || status === "expired" || status === "maxClicks") && (
            <div className="mt-6 text-center">
              <a
                href="/"
                className="inline-flex items-center px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white font-medium transition-colors"
              >
                Back to Home
              </a>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}