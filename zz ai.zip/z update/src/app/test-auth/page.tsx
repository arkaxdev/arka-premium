"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Link2, User, Mail, ArrowRight } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

export default function TestAuthPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Link2 className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-2xl font-bold text-foreground">LinkFlow</h1>
                <p className="text-xs text-muted-foreground">Modern URL Shortener</p>
              </div>
              <div className="sm:hidden">
                <h1 className="text-xl font-bold text-foreground">LinkFlow</h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 sm:space-x-4">
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 md:py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Authentication Pages Test
            </h1>
            <p className="text-lg text-muted-foreground">
              Test the updated login and signup pages with the new design
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Sign In Card */}
            <Card className="bg-card border-border shadow-sm hover:shadow-md transition-all duration-300">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <User className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-xl font-bold text-foreground">
                      Sign In Page
                    </CardTitle>
                    <CardDescription className="text-muted-foreground">
                      Updated with modern design matching the main page
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h4 className="font-medium text-foreground">Features:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Clean header with navigation</li>
                    <li>• Consistent color scheme</li>
                    <li>• Modern card design</li>
                    <li>• Responsive layout</li>
                    <li>• Smooth animations</li>
                  </ul>
                </div>
                <Button 
                  onClick={() => window.location.href = '/auth/signin'}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                >
                  Go to Sign In
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            {/* Sign Up Card */}
            <Card className="bg-card border-border shadow-sm hover:shadow-md transition-all duration-300">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Mail className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-xl font-bold text-foreground">
                      Sign Up Page
                    </CardTitle>
                    <CardDescription className="text-muted-foreground">
                      Updated with modern design matching the main page
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h4 className="font-medium text-foreground">Features:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Clean header with navigation</li>
                    <li>• Consistent color scheme</li>
                    <li>• Modern card design</li>
                    <li>• Responsive layout</li>
                    <li>• Smooth animations</li>
                  </ul>
                </div>
                <Button 
                  onClick={() => window.location.href = '/auth/signup'}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                >
                  Go to Sign Up
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Design Comparison */}
          <Card className="mt-12 bg-card border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-foreground">
                Design Changes Summary
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                What was updated to match the main page design
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Before</h3>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li>• Gradient backgrounds</li>
                    <li>• Dark theme only styling</li>
                    <li>• Centered card layout</li>
                    <li>• Inconsistent header</li>
                    <li>• Different color schemes</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-3">After</h3>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li>• Clean background (bg-background)</li>
                    <li>• Theme-aware colors</li>
                    <li>• Consistent header navigation</li>
                    <li>• Modern card design</li>
                    <li>• Matching main page style</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}