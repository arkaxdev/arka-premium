"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useParams } from "next/navigation"
import { 
  ExternalLink, 
  SkipForward, 
  Timer, 
  Advertisement,
  AlertCircle,
  CheckCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function AdsPage() {
  const params = useParams()
  const code = params.code as string
  const router = useRouter()
  const [countdown, setCountdown] = useState(10)
  const [adData, setAdData] = useState<any>(null)
  const [linkData, setLinkData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    fetchAdAndLinkData()
  }, [code])

  useEffect(() => {
    if (countdown > 0 && !isLoading && !error) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000)
      return () => clearTimeout(timer)
    } else if (countdown === 0 && !error) {
      redirectToDestination()
    }
  }, [countdown, isLoading, error])

  const fetchAdAndLinkData = async () => {
    try {
      // Fetch link data
      const linkResponse = await fetch(`/api/redirect/${code}`)
      if (!linkResponse.ok) {
        const errorData = await linkResponse.json()
        setError(errorData.error || "Link not found")
        setIsLoading(false)
        return
      }

      const linkData = await linkResponse.json()
      setLinkData(linkData)

      // If no ads for this link, redirect immediately
      if (!linkData.showAds) {
        redirectToDestination()
        return
      }

      // Fetch random ad
      const adResponse = await fetch("/api/ads/random")
      if (adResponse.ok) {
        const adData = await adResponse.json()
        setAdData(adData)
      }

      setIsLoading(false)
    } catch (error) {
      setError("Error loading page")
      setIsLoading(false)
    }
  }

  const redirectToDestination = () => {
    if (linkData?.originalUrl) {
      // Record ad impression
      if (adData?.id) {
        fetch(`/api/ads/${adData.id}/impression`, { method: "POST" })
      }
      window.location.href = linkData.originalUrl
    }
  }

  const skipAd = () => {
    redirectToDestination()
  }

  const handleAdClick = () => {
    if (adData?.id) {
      fetch(`/api/ads/${adData.id}/click`, { method: "POST" })
    }
    if (adData?.targetUrl) {
      window.open(adData.targetUrl, "_blank")
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-300">Loading...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md bg-gray-800/50 backdrop-blur-sm border-gray-700">
          <CardContent className="p-8 text-center">
            <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Error</h2>
            <p className="text-gray-400 mb-4">{error}</p>
            <Button onClick={() => router.push("/")}>
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="border-b border-gray-700 bg-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Advertisement className="h-8 w-8 text-blue-400" />
              <h1 className="text-xl font-bold">Advertisement</h1>
              <Badge variant="secondary">Ads</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-300">
                <Timer className="h-4 w-4" />
                <span>{countdown}s</span>
              </div>
              <Button variant="outline" size="sm" onClick={skipAd}>
                <SkipForward className="h-4 w-4 ml-2" />
                Skip Ad
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Redirecting to destination</span>
              <span className="text-sm text-gray-400">{countdown}s</span>
            </div>
            <Progress 
              value={((10 - countdown) / 10) * 100} 
              className="h-2 bg-gray-700"
            />
          </div>

          {/* Ad Content */}
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700 overflow-hidden">
            <CardContent className="p-0">
              {adData ? (
                <div 
                  className="cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={handleAdClick}
                >
                  {adData.imageUrl && (
                    <div className="relative">
                      <img 
                        src={adData.imageUrl} 
                        alt={adData.title}
                        className="w-full h-64 object-cover"
                      />
                      <div className="absolute top-4 right-4">
                        <Badge variant="secondary">Advertisement</Badge>
                      </div>
                    </div>
                  )}
                  <div className="p-6">
                    <h2 className="text-2xl font-bold mb-2">{adData.title}</h2>
                    <p className="text-gray-300 mb-4">{adData.content}</p>
                    <div className="flex items-center justify-between">
                      <Button variant="outline">
                        <ExternalLink className="h-4 w-4 ml-2" />
                        Learn More
                      </Button>
                      <span className="text-sm text-gray-400">
                        Click for more information
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-12 text-center">
                  <Advertisement className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h2 className="text-xl font-bold mb-2">Advertisement</h2>
                  <p className="text-gray-400">
                    Please wait a few seconds to be redirected to your destination
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Info */}
          <div className="mt-8 grid md:grid-cols-2 gap-4">
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <div>
                    <p className="font-medium">Secure Link</p>
                    <p className="text-sm text-gray-400">This link has been verified by our system</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <Timer className="h-5 w-5 text-blue-400" />
                  <div>
                    <p className="font-medium">Auto Redirect</p>
                    <p className="text-sm text-gray-400">You will be redirected automatically in {countdown} seconds</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}