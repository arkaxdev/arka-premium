const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function testAuthDirect() {
  try {
    console.log('=== Testing Authentication Directly ===');
    
    // Get user
    const user = await prisma.user.findUnique({
      where: { email: 'test@example.com' }
    });
    
    if (!user) {
      console.log('User not found');
      return;
    }
    
    console.log('User found:', user.email);
    
    // Test password
    const isPasswordValid = await bcrypt.compare('test123', user.password);
    console.log('Password valid:', isPasswordValid);
    
    if (isPasswordValid) {
      console.log('Authentication would succeed');
      console.log('User data that should be returned:');
      console.log({
        id: user.id,
        email: user.email,
        name: user.name,
        username: user.username,
        isVIP: user.isVIP,
        role: user.role,
        twoFactorEnabled: user.twoFactorEnabled
      });
    } else {
      console.log('Authentication would fail');
    }
    
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testAuthDirect();