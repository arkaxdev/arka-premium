import { DefaultSession } from "next-auth"
import { Role } from "@prisma/client"

declare module "next-auth" {
  interface Session {
    user: {
      id: string
      username?: string
      isVIP: boolean
      role: Role
      twoFactorEnabled: boolean
    } & DefaultSession["user"]
  }

  interface User {
    username?: string
    isVIP: boolean
    role: Role
    twoFactorEnabled: boolean
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    username?: string
    isVIP: boolean
    role: Role
    twoFactorEnabled: boolean
  }
}