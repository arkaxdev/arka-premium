"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { 
  Users, 
  Link as LinkIcon, 
  BarChart3, 
  DollarSign, 
  Activity,
  TrendingUp,
  TrendingDown,
  Eye,
  MousePointer,
  Globe,
  Smartphone,
  Monitor,
  Clock,
  Calendar,
  ArrowUp,
  ArrowDown,
  MoreVertical,
  Download,
  RefreshCw,
  Filter,
  ChevronRight,
  Megaphone,
  CreditCard,
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Server,
  Database,
  Cpu,
  HardDrive,
  Wifi,
  Zap
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { useToast } from "@/hooks/use-toast"
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

// نمونه داده‌ها برای نمودارها
const revenueData = [
  { name: 'فروردین', revenue: 4000, users: 240, clicks: 2400 },
  { name: 'اردیبهشت', revenue: 3000, users: 139, clicks: 2210 },
  { name: 'خرداد', revenue: 2000, users: 980, clicks: 2290 },
  { name: 'تیر', revenue: 2780, users: 390, clicks: 2000 },
  { name: 'مرداد', revenue: 1890, users: 480, clicks: 2181 },
  { name: 'شهریور', revenue: 2390, users: 380, clicks: 2500 },
  { name: 'مهر', revenue: 3490, users: 430, clicks: 2100 },
]

const deviceData = [
  { name: 'Desktop', value: 45, color: '#FF6B6B' },
  { name: 'Mobile', value: 35, color: '#4ECDC4' },
  { name: 'Tablet', value: 20, color: '#45B7D1' },
]

const countryData = [
  { country: 'ایران', users: 4500, clicks: 12000, revenue: 2500 },
  { country: 'آمریکا', users: 3200, clicks: 8500, revenue: 1800 },
  { country: 'آلمان', users: 2100, clicks: 5600, revenue: 1200 },
  { country: 'انگلستان', users: 1800, clicks: 4200, revenue: 950 },
  { country: 'کانادا', users: 1500, clicks: 3800, revenue: 800 },
]

interface SystemStats {
  totalUsers: number
  totalLinks: number
  totalClicks: number
  totalVipUsers: number
  totalRevenue: number
  todayUsers: number
  todayLinks: number
  todayClicks: number
  todayRevenue: number
  activeUsers: number
  serverStatus: {
    cpu: number
    memory: number
    disk: number
    uptime: string
  }
  recentActivities: Array<{
    id: string
    type: string
    message: string
    time: string
    icon: any
  }>
}

export default function AdminDashboard() {
  const { toast } = useToast()
  const [stats, setStats] = useState<SystemStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [timeRange, setTimeRange] = useState("today")
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    fetchStats()
    const interval = setInterval(fetchStats, 30000) // هر 30 ثانیه
    return () => clearInterval(interval)
  }, [])

  const fetchStats = async () => {
    try {
      const response = await fetch("/api/admin/stats")
      if (response.ok) {
        const data = await response.json()
        setStats({
          ...data,
          activeUsers: 152,
          serverStatus: {
            cpu: 45,
            memory: 62,
            disk: 38,
            uptime: "99.9%"
          },
          recentActivities: [
            { id: '1', type: 'user', message: 'کاربر جدید ثبت نام کرد', time: '5 دقیقه پیش', icon: Users },
            { id: '2', type: 'link', message: '50 لینک جدید ایجاد شد', time: '15 دقیقه پیش', icon: LinkIcon },
            { id: '3', type: 'payment', message: 'پرداخت جدید دریافت شد', time: '1 ساعت پیش', icon: CreditCard },
            { id: '4', type: 'ad', message: 'کمپین تبلیغاتی جدید', time: '2 ساعت پیش', icon: Megaphone },
            { id: '5', type: 'security', message: 'تلاش ورود ناموفق شناسایی شد', time: '3 ساعت پیش', icon: Shield },
          ]
        })
      }
    } catch (error) {
      toast({
        title: "خطا",
        description: "دریافت آمار با مشکل مواجه شد",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
      setRefreshing(false)
    }
  }

  const handleRefresh = () => {
    setRefreshing(true)
    fetchStats()
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-16 h-16 border-4 border-transparent border-t-primary rounded-full"
        />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">داشبورد مدیریت</h1>
          <p className="text-muted-foreground mt-1">خلاصه‌ای از وضعیت سیستم و عملکرد</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">امروز</SelectItem>
              <SelectItem value="week">این هفته</SelectItem>
              <SelectItem value="month">این ماه</SelectItem>
              <SelectItem value="year">امسال</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={handleRefresh} disabled={refreshing}>
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
          <Button>
            <Download className="h-4 w-4 ml-2" />
            دانلود گزارش
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-card border-border hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">کل کاربران</CardTitle>
              <Users className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.totalUsers?.toLocaleString() || 0}</div>
              <div className="flex items-center mt-2 text-sm">
                <ArrowUp className="h-4 w-4 text-green-500 ml-1" />
                <span className="text-green-500 font-medium">+{stats?.todayUsers || 0}</span>
                <span className="text-muted-foreground mr-2">امروز</span>
              </div>
              <Progress value={75} className="mt-3 h-1" />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-card border-border hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">کل لینک‌ها</CardTitle>
              <LinkIcon className="h-5 w-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.totalLinks?.toLocaleString() || 0}</div>
              <div className="flex items-center mt-2 text-sm">
                <ArrowUp className="h-4 w-4 text-green-500 ml-1" />
                <span className="text-green-500 font-medium">+{stats?.todayLinks || 0}</span>
                <span className="text-muted-foreground mr-2">امروز</span>
              </div>
              <Progress value={60} className="mt-3 h-1" />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-card border-border hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">کل کلیک‌ها</CardTitle>
              <MousePointer className="h-5 w-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.totalClicks?.toLocaleString() || 0}</div>
              <div className="flex items-center mt-2 text-sm">
                <ArrowUp className="h-4 w-4 text-green-500 ml-1" />
                <span className="text-green-500 font-medium">+{stats?.todayClicks?.toLocaleString() || 0}</span>
                <span className="text-muted-foreground mr-2">امروز</span>
              </div>
              <Progress value={85} className="mt-3 h-1" />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-card border-border hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">درآمد کل</CardTitle>
              <DollarSign className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">
                ${stats?.totalRevenue?.toFixed(2) || 0}
              </div>
              <div className="flex items-center mt-2 text-sm">
                <ArrowUp className="h-4 w-4 text-green-500 ml-1" />
                <span className="text-green-500 font-medium">+${stats?.todayRevenue?.toFixed(2) || 0}</span>
                <span className="text-muted-foreground mr-2">امروز</span>
              </div>
              <Progress value={90} className="mt-3 h-1" />
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts and Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>نمودار درآمد و کاربران</CardTitle>
                <CardDescription>روند درآمد و رشد کاربران در 7 ماه گذشته</CardDescription>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>صادرات داده‌ها</DropdownMenuItem>
                  <DropdownMenuItem>چاپ نمودار</DropdownMenuItem>
                  <DropdownMenuItem>تنظیمات</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF6B6B" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#FF6B6B" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4ECDC4" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#4ECDC4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#FF6B6B" fillOpacity={1} fill="url(#colorRevenue)" />
                <Area type="monotone" dataKey="users" stroke="#4ECDC4" fillOpacity={1} fill="url(#colorUsers)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Device Distribution */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>توزیع دستگاه‌ها</CardTitle>
                <CardDescription>نوع دستگاه‌های استفاده شده توسط کاربران</CardDescription>
              </div>
              <Badge variant="secondary" className="bg-primary/10 text-primary border-0">
                زنده
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={deviceData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {deviceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              {deviceData.map((device) => (
                <div key={device.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: device.color }}></div>
                    <span className="text-sm text-muted-foreground">{device.name}</span>
                  </div>
                  <span className="text-sm font-medium">{device.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Status and Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* System Health */}
        <Card className="bg-card border-border lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5 text-primary" />
              وضعیت سیستم
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground flex items-center gap-2">
                  <Cpu className="h-4 w-4" />
                  CPU
                </span>
                <span className="text-sm font-medium">{stats?.serverStatus.cpu}%</span>
              </div>
              <Progress value={stats?.serverStatus.cpu} className="h-2" />
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground flex items-center gap-2">
                  <Database className="h-4 w-4" />
                  حافظه
                </span>
                <span className="text-sm font-medium">{stats?.serverStatus.memory}%</span>
              </div>
              <Progress value={stats?.serverStatus.memory} className="h-2" />
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground flex items-center gap-2">
                  <HardDrive className="h-4 w-4" />
                  فضای دیسک
                </span>
                <span className="text-sm font-medium">{stats?.serverStatus.disk}%</span>
              </div>
              <Progress value={stats?.serverStatus.disk} className="h-2" />
            </div>

            <div className="pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Uptime</span>
                <Badge variant="secondary" className="bg-green-500/10 text-green-600 border-0">
                  {stats?.serverStatus.uptime}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activities */}
        <Card className="bg-card border-border lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>فعالیت‌های اخیر</CardTitle>
              <Button variant="ghost" size="sm">
                مشاهده همه
                <ChevronRight className="h-4 w-4 mr-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats?.recentActivities.map((activity) => {
                const Icon = activity.icon
                return (
                  <motion.div
                    key={activity.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center
                      ${activity.type === 'user' ? 'bg-blue-500/10 text-blue-600' :
                        activity.type === 'link' ? 'bg-green-500/10 text-green-600' :
                        activity.type === 'payment' ? 'bg-primary/10 text-primary' :
                        activity.type === 'ad' ? 'bg-purple-500/10 text-purple-600' :
                        'bg-red-500/10 text-red-600'
                      }`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">{activity.message}</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Countries Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>کشورهای برتر</CardTitle>
              <CardDescription>کشورهایی با بیشترین فعالیت</CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 ml-2" />
              فیلتر
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>کشور</TableHead>
                <TableHead className="text-center">کاربران</TableHead>
                <TableHead className="text-center">کلیک‌ها</TableHead>
                <TableHead className="text-center">درآمد</TableHead>
                <TableHead className="text-left">عملکرد</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {countryData.map((country, index) => (
                <TableRow key={country.country}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      {country.country}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">{country.users.toLocaleString()}</TableCell>
                  <TableCell className="text-center">{country.clicks.toLocaleString()}</TableCell>
                  <TableCell className="text-center">${country.revenue.toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={(country.revenue / 2500) * 100} className="flex-1 h-2" />
                      <span className="text-xs text-muted-foreground w-10">
                        {Math.round((country.revenue / 2500) * 100)}%
                      </span>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-primary/10 border-primary/20 hover:bg-primary/20 transition-colors cursor-pointer">
          <CardContent className="p-6 text-center">
            <Users className="h-8 w-8 text-primary mx-auto mb-2" />
            <p className="text-sm font-medium">افزودن کاربر جدید</p>
          </CardContent>
        </Card>
        <Card className="bg-green-500/10 border-green-500/20 hover:bg-green-500/20 transition-colors cursor-pointer">
          <CardContent className="p-6 text-center">
            <Megaphone className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <p className="text-sm font-medium">ایجاد کمپین تبلیغاتی</p>
          </CardContent>
        </Card>
        <Card className="bg-purple-500/10 border-purple-500/20 hover:bg-purple-500/20 transition-colors cursor-pointer">
          <CardContent className="p-6 text-center">
            <BarChart3 className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <p className="text-sm font-medium">مشاهده گزارش‌ها</p>
          </CardContent>
        </Card>
        <Card className="bg-blue-500/10 border-blue-500/20 hover:bg-blue-500/20 transition-colors cursor-pointer">
          <CardContent className="p-6 text-center">
            <Shield className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <p className="text-sm font-medium">تنظیمات امنیتی</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
