"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { 
  Users, 
  UserPlus,
  Search,
  Filter,
  Download,
  Upload,
  MoreVertical,
  Mail,
  Shield,
  Crown,
  Ban,
  Check,
  X,
  Eye,
  Edit,
  Trash2,
  Key,
  UserCheck,
  UserCog,
  ArrowUpDown,
  RefreshCw,
  Link as LinkIcon,
  MousePointer,
  DollarSign,
  CheckCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "@/components/ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"

interface User {
  id: string
  email: string
  name?: string
  username?: string
  avatar?: string
  role: "ADMIN" | "VIP" | "FREE"
  isActive: boolean
  emailVerified: boolean
  twoFactorEnabled: boolean
  createdAt: string
  lastLoginAt?: string
  _count: {
    links: number
    payments: number
  }
  stats: {
    totalClicks: number
    totalRevenue: number
    lastActivity: string
  }
}

// نمونه داده‌های کاربران
const sampleUsers: User[] = [
  {
    id: "1",
    email: "admin@linkflow.com",
    name: "مدیر سیستم",
    username: "admin",
    role: "ADMIN",
    isActive: true,
    emailVerified: true,
    twoFactorEnabled: true,
    createdAt: "2024-01-01T00:00:00Z",
    lastLoginAt: "2024-03-20T10:30:00Z",
    _count: { links: 150, payments: 0 },
    stats: { totalClicks: 5000, totalRevenue: 0, lastActivity: "5 دقیقه پیش" }
  },
  {
    id: "2",
    email: "vip@example.com",
    name: "کاربر ویژه",
    username: "vipuser",
    role: "VIP",
    isActive: true,
    emailVerified: true,
    twoFactorEnabled: false,
    createdAt: "2024-02-15T00:00:00Z",
    lastLoginAt: "2024-03-19T15:45:00Z",
    _count: { links: 85, payments: 5 },
    stats: { totalClicks: 3500, totalRevenue: 150, lastActivity: "2 ساعت پیش" }
  },
  {
    id: "3",
    email: "user@example.com",
    name: "کاربر عادی",
    username: "normaluser",
    role: "FREE",
    isActive: true,
    emailVerified: false,
    twoFactorEnabled: false,
    createdAt: "2024-03-01T00:00:00Z",
    lastLoginAt: "2024-03-18T09:00:00Z",
    _count: { links: 25, payments: 0 },
    stats: { totalClicks: 500, totalRevenue: 0, lastActivity: "1 روز پیش" }
  }
]

export default function UsersManagement() {
  const { toast } = useToast()
  const [users, setUsers] = useState<User[]>(sampleUsers)
  const [searchQuery, setSearchQuery] = useState("")
  const [roleFilter, setRoleFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedUsers, setSelectedUsers] = useState<string[]>([])
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.username?.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesRole = roleFilter === "all" || user.role === roleFilter
    const matchesStatus = statusFilter === "all" || 
                         (statusFilter === "active" && user.isActive) ||
                         (statusFilter === "inactive" && !user.isActive)
    
    return matchesSearch && matchesRole && matchesStatus
  })

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedUsers(filteredUsers.map(user => user.id))
    } else {
      setSelectedUsers([])
    }
  }

  const handleSelectUser = (userId: string, checked: boolean) => {
    if (checked) {
      setSelectedUsers([...selectedUsers, userId])
    } else {
      setSelectedUsers(selectedUsers.filter(id => id !== userId))
    }
  }

  const handleBulkAction = async (action: string) => {
    setIsLoading(true)
    try {
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      toast({
        title: "عملیات موفق",
        description: `${selectedUsers.length} کاربر ${action} شدند`,
      })
      
      setSelectedUsers([])
    } catch (error) {
      toast({
        title: "خطا",
        description: "عملیات با مشکل مواجه شد",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">مدیریت کاربران</h1>
          <p className="text-muted-foreground mt-1">
            مدیریت کامل کاربران، دسترسی‌ها و اطلاعات
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">
            <Upload className="h-4 w-4 ml-2" />
            ورود گروهی
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 ml-2" />
            خروجی Excel
          </Button>
          <Button 
            className="bg-primary hover:bg-primary/90"
            onClick={() => setShowCreateDialog(true)}
          >
            <UserPlus className="h-4 w-4 ml-2" />
            کاربر جدید
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              کل کاربران
            </CardTitle>
            <Users className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +12% نسبت به ماه قبل
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              کاربران فعال
            </CardTitle>
            <UserCheck className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {users.filter(u => u.isActive).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {Math.round((users.filter(u => u.isActive).length / users.length) * 100)}% از کل
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              کاربران VIP
            </CardTitle>
            <Crown className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {users.filter(u => u.role === "VIP").length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              درآمد ماهانه: $2,500
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              کاربران جدید
            </CardTitle>
            <UserPlus className="h-5 w-5 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45</div>
            <p className="text-xs text-muted-foreground mt-1">
              در 30 روز گذشته
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="جستجو در کاربران..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-3">
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="نقش" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه نقش‌ها</SelectItem>
                  <SelectItem value="ADMIN">مدیر</SelectItem>
                  <SelectItem value="VIP">VIP</SelectItem>
                  <SelectItem value="FREE">رایگان</SelectItem>
                </SelectContent>
              </Select>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="وضعیت" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  <SelectItem value="active">فعال</SelectItem>
                  <SelectItem value="inactive">غیرفعال</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" size="icon">
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Bulk Actions */}
          {selectedUsers.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-4 bg-muted/50 rounded-lg flex items-center justify-between"
            >
              <span className="text-sm text-muted-foreground">
                {selectedUsers.length} کاربر انتخاب شده
              </span>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction("activate")}
                >
                  <Check className="h-4 w-4 ml-1" />
                  فعال‌سازی
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction("deactivate")}
                >
                  <X className="h-4 w-4 ml-1" />
                  غیرفعال‌سازی
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction("delete")}
                  className="text-destructive"
                >
                  <Trash2 className="h-4 w-4 ml-1" />
                  حذف
                </Button>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <ScrollArea className="w-full">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">
                    <Checkbox
                      checked={selectedUsers.length === filteredUsers.length && filteredUsers.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead>کاربر</TableHead>
                  <TableHead>نقش</TableHead>
                  <TableHead>وضعیت</TableHead>
                  <TableHead>آمار</TableHead>
                  <TableHead>آخرین فعالیت</TableHead>
                  <TableHead>عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <Checkbox
                        checked={selectedUsers.includes(user.id)}
                        onCheckedChange={(checked) => handleSelectUser(user.id, checked as boolean)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={user.avatar} />
                          <AvatarFallback className="bg-primary/10 text-primary">
                            {user.name?.charAt(0) || user.email.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-foreground">
                            {user.name || user.username || "بدون نام"}
                          </p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={user.role === "ADMIN" ? "default" : "secondary"}
                        className={
                          user.role === "ADMIN"
                            ? "bg-destructive/10 text-destructive border-destructive/20"
                            : user.role === "VIP"
                            ? "bg-primary/10 text-primary border-primary/20"
                            : ""
                        }
                      >
                        {user.role === "ADMIN" && <Shield className="h-3 w-3 ml-1" />}
                        {user.role === "VIP" && <Crown className="h-3 w-3 ml-1" />}
                        {user.role}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-2 h-2 rounded-full ${
                              user.isActive ? "bg-green-500" : "bg-red-500"
                            }`}
                          />
                          <span className="text-sm">
                            {user.isActive ? "فعال" : "غیرفعال"}
                          </span>
                        </div>
                        {user.emailVerified && (
                          <Badge variant="outline" className="text-xs w-fit">
                            <CheckCircle className="h-3 w-3 ml-1" />
                            تایید شده
                          </Badge>
                        )}
                        {user.twoFactorEnabled && (
                          <Badge variant="outline" className="text-xs w-fit">
                            <Key className="h-3 w-3 ml-1" />
                            2FA
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1 text-sm">
                        <div className="flex items-center gap-2">
                          <LinkIcon className="h-3 w-3 text-muted-foreground" />
                          <span>{user._count.links} لینک</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MousePointer className="h-3 w-3 text-muted-foreground" />
                          <span>{user.stats.totalClicks.toLocaleString()} کلیک</span>
                        </div>
                        {user.role === "VIP" && (
                          <div className="flex items-center gap-2">
                            <DollarSign className="h-3 w-3 text-muted-foreground" />
                            <span>${user.stats.totalRevenue}</span>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <p className="text-muted-foreground">{user.stats.lastActivity}</p>
                        {user.lastLoginAt && (
                          <p className="text-xs text-muted-foreground">
                            ورود: {new Date(user.lastLoginAt).toLocaleDateString("fa-IR")}
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-[200px]">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 ml-2" />
                            مشاهده جزئیات
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 ml-2" />
                            ویرایش اطلاعات
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Mail className="h-4 w-4 ml-2" />
                            ارسال پیام
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Key className="h-4 w-4 ml-2" />
                            بازنشانی رمز عبور
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <UserCog className="h-4 w-4 ml-2" />
                            تغییر نقش
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive">
                            <Ban className="h-4 w-4 ml-2" />
                            مسدود کردن
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="h-4 w-4 ml-2" />
                            حذف کاربر
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Create User Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>ایجاد کاربر جدید</DialogTitle>
            <DialogDescription>
              اطلاعات کاربر جدید را وارد کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="email">ایمیل</Label>
              <Input id="email" type="email" placeholder="user@example.com" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">نام</Label>
              <Input id="name" placeholder="نام کاربر" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">نقش</Label>
              <Select defaultValue="FREE">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="FREE">کاربر رایگان</SelectItem>
                  <SelectItem value="VIP">کاربر VIP</SelectItem>
                  <SelectItem value="ADMIN">مدیر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="active">فعال بودن حساب</Label>
              <Switch id="active" defaultChecked />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              انصراف
            </Button>
            <Button onClick={() => {
              toast({
                title: "کاربر ایجاد شد",
                description: "کاربر جدید با موفقیت ایجاد شد",
              })
              setShowCreateDialog(false)
            }}>
              ایجاد کاربر
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
