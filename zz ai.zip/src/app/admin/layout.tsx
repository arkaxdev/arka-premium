"use client"

import { useState } from "react"
import { useSession } from "next-auth/react"
import { useRouter, usePathname } from "next/navigation"
import { motion } from "framer-motion"
import { 
  Users, 
  Link as LinkIcon, 
  BarChart3, 
  DollarSign, 
  Settings, 
  LogOut,
  Shield,
  Megaphone,
  CreditCard,
  Globe,
  Server,
  Database,
  FileText,
  MessageSquare,
  Key,
  Menu,
  X,
  ChevronDown,
  UserCog,
  LinkIcon as Links,
  TrendingUp,
  ShieldCheck,
  Headphones,
  Code,
  Bell,
  Search
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { signOut } from "next-auth/react"
import { cn } from "@/lib/utils"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"

const menuItems = [
  {
    title: "داشبورد",
    icon: BarChart3,
    href: "/admin",
    badge: null
  },
  {
    title: "مدیریت کاربران",
    icon: Users,
    href: "/admin/users",
    badge: "جدید",
    subItems: [
      { title: "همه کاربران", href: "/admin/users" },
      { title: "کاربران VIP", href: "/admin/users/vip" },
      { title: "کاربران مسدود", href: "/admin/users/blocked" },
      { title: "نقش‌ها و دسترسی‌ها", href: "/admin/users/roles" }
    ]
  },
  {
    title: "مدیریت لینک‌ها",
    icon: LinkIcon,
    href: "/admin/links",
    subItems: [
      { title: "همه لینک‌ها", href: "/admin/links" },
      { title: "لینک‌های گزارش شده", href: "/admin/links/reported" },
      { title: "لینک‌های منقضی", href: "/admin/links/expired" },
      { title: "آمار لینک‌ها", href: "/admin/links/analytics" }
    ]
  },
  {
    title: "مدیریت تبلیغات",
    icon: Megaphone,
    href: "/admin/ads",
    badge: "5",
    subItems: [
      { title: "کمپین‌های تبلیغاتی", href: "/admin/ads/campaigns" },
      { title: "تبلیغ‌دهندگان", href: "/admin/ads/advertisers" },
      { title: "گزارش عملکرد", href: "/admin/ads/performance" },
      { title: "تنظیمات تبلیغات", href: "/admin/ads/settings" }
    ]
  },
  {
    title: "مالی و پرداخت‌ها",
    icon: CreditCard,
    href: "/admin/payments",
    subItems: [
      { title: "تراکنش‌ها", href: "/admin/payments/transactions" },
      { title: "اشتراک‌ها", href: "/admin/payments/subscriptions" },
      { title: "صورتحساب‌ها", href: "/admin/payments/invoices" },
      { title: "گزارش درآمد", href: "/admin/payments/revenue" }
    ]
  },
  {
    title: "گزارش‌ها و آمار",
    icon: TrendingUp,
    href: "/admin/analytics",
    subItems: [
      { title: "آمار کلی", href: "/admin/analytics/overview" },
      { title: "آمار جغرافیایی", href: "/admin/analytics/geo" },
      { title: "آمار دستگاه‌ها", href: "/admin/analytics/devices" },
      { title: "گزارش‌های سفارشی", href: "/admin/analytics/custom" }
    ]
  },
  {
    title: "امنیت",
    icon: ShieldCheck,
    href: "/admin/security",
    subItems: [
      { title: "لاگ‌های امنیتی", href: "/admin/security/logs" },
      { title: "IP های مسدود", href: "/admin/security/blocked-ips" },
      { title: "تنظیمات فایروال", href: "/admin/security/firewall" },
      { title: "احراز هویت دو مرحله‌ای", href: "/admin/security/2fa" }
    ]
  },
  {
    title: "پشتیبانی",
    icon: Headphones,
    href: "/admin/support",
    badge: "12",
    subItems: [
      { title: "تیکت‌ها", href: "/admin/support/tickets" },
      { title: "پیام‌های کاربران", href: "/admin/support/messages" },
      { title: "سوالات متداول", href: "/admin/support/faq" },
      { title: "راهنما و مستندات", href: "/admin/support/docs" }
    ]
  },
  {
    title: "API",
    icon: Code,
    href: "/admin/api",
    subItems: [
      { title: "کلیدهای API", href: "/admin/api/keys" },
      { title: "محدودیت‌ها", href: "/admin/api/limits" },
      { title: "لاگ درخواست‌ها", href: "/admin/api/logs" },
      { title: "مستندات API", href: "/admin/api/docs" }
    ]
  },
  {
    title: "تنظیمات سیستم",
    icon: Settings,
    href: "/admin/settings",
    subItems: [
      { title: "تنظیمات عمومی", href: "/admin/settings/general" },
      { title: "تنظیمات ایمیل", href: "/admin/settings/email" },
      { title: "تنظیمات پرداخت", href: "/admin/settings/payment" },
      { title: "پشتیبان‌گیری", href: "/admin/settings/backup" }
    ]
  }
]

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { data: session, status } = useSession()
  const router = useRouter()
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [expandedItems, setExpandedItems] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState("")

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-16 h-16 border-4 border-transparent border-t-primary rounded-full mx-auto"
          />
          <p className="mt-4 text-muted-foreground text-lg">در حال بارگذاری پنل ادمین...</p>
        </div>
      </div>
    )
  }

  if (!session || session.user?.role !== "ADMIN") {
    router.push("/")
    return null
  }

  const toggleExpanded = (title: string) => {
    setExpandedItems(prev => 
      prev.includes(title) 
        ? prev.filter(item => item !== title)
        : [...prev, title]
    )
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: sidebarOpen ? 0 : -300 }}
        transition={{ duration: 0.3 }}
        className="fixed top-0 left-0 h-full w-72 bg-card border-r border-border z-40"
      >
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Shield className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">پنل ادمین</h1>
              <p className="text-xs text-muted-foreground">LinkFlow Admin</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Search */}
        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="جستجو در منو..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 text-sm"
            />
          </div>
        </div>

        {/* Menu Items */}
        <ScrollArea className="h-[calc(100vh-180px)]">
          <nav className="p-4 space-y-2">
            {menuItems.map((item) => {
              const isActive = pathname === item.href || pathname.startsWith(item.href + "/")
              const isExpanded = expandedItems.includes(item.title)
              const Icon = item.icon

              return (
                <div key={item.href}>
                  <div
                    className={cn(
                      "flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors",
                      isActive 
                        ? "bg-primary/10 text-primary" 
                        : "hover:bg-muted/50 text-muted-foreground hover:text-foreground"
                    )}
                    onClick={() => {
                      if (item.subItems) {
                        toggleExpanded(item.title)
                      } else {
                        router.push(item.href)
                      }
                    }}
                  >
                    <div className="flex items-center space-x-3">
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{item.title}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      {item.badge && (
                        <Badge variant="secondary" className="bg-primary/10 text-primary border-0">
                          {item.badge}
                        </Badge>
                      )}
                      {item.subItems && (
                        <ChevronDown 
                          className={cn(
                            "h-4 w-4 transition-transform",
                            isExpanded && "rotate-180"
                          )}
                        />
                      )}
                    </div>
                  </div>

                  {/* Sub Items */}
                  {item.subItems && isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-2 mr-8 space-y-1"
                    >
                      {item.subItems.map((subItem) => {
                        const isSubActive = pathname === subItem.href
                        return (
                          <div
                            key={subItem.href}
                            onClick={() => router.push(subItem.href)}
                            className={cn(
                              "p-2 rounded-md cursor-pointer text-sm transition-colors",
                              isSubActive
                                ? "bg-primary/10 text-primary"
                                : "hover:bg-muted/50 text-muted-foreground hover:text-foreground"
                            )}
                          >
                            {subItem.title}
                          </div>
                        )
                      })}
                    </motion.div>
                  )}
                </div>
              )
            })}
          </nav>
        </ScrollArea>

        {/* User Info */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-border bg-card">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="w-full justify-start">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-primary-foreground text-sm font-medium">
                      {session.user?.name?.charAt(0) || "A"}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-foreground">{session.user?.name}</p>
                    <p className="text-xs text-muted-foreground">مدیر سیستم</p>
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>حساب کاربری</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => router.push("/admin/profile")}>
                <UserCog className="h-4 w-4 ml-2" />
                پروفایل
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/admin/settings")}>
                <Settings className="h-4 w-4 ml-2" />
                تنظیمات
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => signOut()} className="text-destructive">
                <LogOut className="h-4 w-4 ml-2" />
                خروج
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </motion.aside>

      {/* Main Content */}
      <div className={cn(
        "flex-1 transition-all duration-300",
        sidebarOpen ? "mr-72" : "mr-0"
      )}>
        {/* Top Bar */}
        <header className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <h2 className="text-xl font-semibold text-foreground">
                {pathname === "/admin" ? "داشبورد" : ""}
              </h2>
            </div>

            <div className="flex items-center space-x-4">
              {/* Notifications */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="h-5 w-5" />
                    <span className="absolute -top-1 -right-1 w-2 h-2 bg-destructive rounded-full"></span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <DropdownMenuLabel>اعلان‌ها</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <div className="max-h-96 overflow-y-auto">
                    <DropdownMenuItem className="flex flex-col items-start p-3">
                      <p className="text-sm font-medium">کاربر جدید ثبت نام کرد</p>
                      <p className="text-xs text-muted-foreground">5 دقیقه پیش</p>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="flex flex-col items-start p-3">
                      <p className="text-sm font-medium">گزارش جدید دریافت شد</p>
                      <p className="text-xs text-muted-foreground">1 ساعت پیش</p>
                    </DropdownMenuItem>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Quick Stats */}
              <div className="hidden lg:flex items-center space-x-6 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-muted-foreground">سیستم فعال</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">152 آنلاین</span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  )
}
