"use client"

import React, { useState, useEffect } from "react"
import { useSession, signIn, signOut } from "next-auth/react"
import { useRouter } from "next/navigation"
import { 
  Link2, 
  Copy, 
  Check, 
  ExternalLink, 
  BarChart3, 
  User, 
  Settings,
  Sparkles,
  Zap,
  Shield,
  TrendingUp,
  ArrowRight,
  Star,
  Rocket,
  Target,
  Globe,
  Smartphone,
  Crown,
  Wand2,
  Infinity,
  CheckCircle,
  ArrowUp,
  MousePointer
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ThemeToggle } from "@/components/theme-toggle"
import { useToast } from "@/hooks/use-toast"
import { motion, AnimatePresence } from "framer-motion"

export default function Home() {
  const [url, setUrl] = useState("")
  const [customSlug, setCustomSlug] = useState("")
  const [shortUrl, setShortUrl] = useState("")
  const [isCopied, setIsCopied] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const { data: session, status } = useSession()
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    if (status === "loading") return
    
    if (session) {
      // Use replace instead of push to avoid history issues
      router.replace("/dashboard")
    }
  }, [session, status, router])

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300)
    }
    
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleShorten = async () => {
    if (!url) {
      toast({
        title: "Error",
        description: "Please enter a valid URL",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/shorten", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url,
          customSlug: customSlug || undefined,
        }),
      })

      if (!response.ok) {
        throw new Error("Error shortening URL")
      }

      const data = await response.json()
      setShortUrl(data.shortUrl)
      toast({
        title: "Success!",
        description: "Your link has been shortened successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to shorten URL",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shortUrl)
      setIsCopied(true)
      setTimeout(() => setIsCopied(false), 2000)
      toast({
        title: "Copied!",
        description: "Link copied to clipboard",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy link",
        variant: "destructive",
      })
    }
  }

  const features = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Instant URL redirection with global CDN"
    },
    {
      icon: Shield,
      title: "Secure & Private",
      description: "Enterprise-grade security for your links"
    },
    {
      icon: TrendingUp,
      title: "Advanced Analytics",
      description: "Real-time statistics and insights"
    },
    {
      icon: Infinity,
      title: "Unlimited Links",
      description: "Create as many short links as you need"
    },
    {
      icon: Smartphone,
      title: "Mobile Optimized",
      description: "Perfect experience on all devices"
    },
    {
      icon: Crown,
      title: "Premium Features",
      description: "Unlock powerful tools with VIP"
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Link2 className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-2xl font-bold text-foreground">LinkFlow</h1>
                <p className="text-xs text-muted-foreground">Modern URL Shortener</p>
              </div>
              <div className="sm:hidden">
                <h1 className="text-xl font-bold text-foreground">LinkFlow</h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 sm:space-x-4">
              <ThemeToggle />
              {status === "loading" ? (
                <div className="w-8 h-8 bg-muted rounded-full animate-pulse"></div>
              ) : session ? (
                <>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => router.push("/dashboard")}
                    className="text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-200 hidden sm:flex"
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Dashboard
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => signOut()}
                    className="text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-200"
                  >
                    <User className="h-4 w-4 mr-2 hidden sm:block" />
                    <span className="hidden sm:inline">Sign Out</span>
                  </Button>
                </>
              ) : (
                <>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => signIn()}
                    className="text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-200 hidden sm:flex"
                  >
                    <User className="h-4 w-4 mr-2" />
                    Sign In
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => router.push("/auth/signup")}
                    className="text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-200 hidden sm:flex"
                  >
                    Sign Up
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => signIn()}
                    className="text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-200 sm:hidden"
                  >
                    <User className="h-4 w-4" />
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 md:py-16">
        <div className="max-w-4xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12 md:mb-16">
            <div className="flex justify-center mb-6">
              <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 text-sm px-4 py-2 rounded-full">
                <Rocket className="h-4 w-4 mr-2" />
                Most Modern URL Shortener
              </Badge>
            </div>
            
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 text-foreground leading-tight">
              Shorten Your Links
              <br />
              <span className="text-primary">
                Like Magic
              </span>
            </h1>
            
            <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              Experience the most powerful, beautiful, and intelligent URL shortener. 
              Create beautiful short links with advanced analytics and seamless sharing.
            </p>

            {/* URL Shortener Form */}
            <Card className="bg-card border-border shadow-sm hover:shadow-md transition-all duration-300">
              <CardHeader className="text-center pb-6">
                <CardTitle className="text-xl font-bold text-foreground">
                  Create Your Short Link
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  Transform any long URL into a beautiful, shareable short link
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 px-6 pb-6">
                <div className="space-y-4">
                  <div className="relative">
                    <Input
                      type="url"
                      placeholder="https://your-long-url-here.com"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      className="h-12 text-base pr-12 border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-200"
                    />
                    <Globe className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                  </div>
                  
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Custom slug (optional)"
                      value={customSlug}
                      onChange={(e) => setCustomSlug(e.target.value)}
                      className="h-12 text-base pr-12 border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-200"
                    />
                    <Wand2 className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                  </div>
                  
                  <Button 
                    onClick={handleShorten} 
                    disabled={isLoading}
                    className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-base rounded-lg transition-all duration-300"
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary-foreground mr-2"></div>
                        Creating...
                      </div>
                    ) : (
                      <div className="flex items-center justify-center">
                        <Sparkles className="h-5 w-5 mr-2" />
                        Create Short Link
                      </div>
                    )}
                  </Button>
                </div>

                <AnimatePresence>
                  {shortUrl && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                      className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4"
                    >
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                        <div className="flex items-center min-w-0 flex-1">
                          <CheckCircle className="h-4 w-4 text-green-600 mr-2 flex-shrink-0" />
                          <span className="text-green-800 dark:text-green-300 font-medium text-sm break-all">
                            {shortUrl}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            onClick={copyToClipboard}
                            variant="outline"
                            size="sm"
                            className="border-green-200 dark:border-green-800 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900/30"
                          >
                            {isCopied ? (
                              <Check className="h-4 w-4" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                          <Button
                            onClick={() => window.open(shortUrl, '_blank')}
                            variant="outline"
                            size="sm"
                            className="border-green-200 dark:border-green-800 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900/30"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* Features Section */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-12 text-foreground">
              Why Choose LinkFlow?
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <Card 
                  key={index} 
                  className="bg-card border-border hover:shadow-md transition-all duration-300 hover:border-primary/50"
                >
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg font-semibold text-foreground">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-muted-foreground">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Stats Section */}
          <div className="grid md:grid-cols-3 gap-6 mb-16">
            <Card className="bg-card border-border text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-primary mb-2">1M+</div>
                <p className="text-muted-foreground">Links Shortened</p>
              </CardContent>
            </Card>
            <Card className="bg-card border-border text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-primary mb-2">99.9%</div>
                <p className="text-muted-foreground">Uptime Guaranteed</p>
              </CardContent>
            </Card>
            <Card className="bg-card border-border text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-primary mb-2">24/7</div>
                <p className="text-muted-foreground">Customer Support</p>
              </CardContent>
            </Card>
          </div>

          {/* CTA Section */}
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4 text-foreground">
              Ready to Get Started?
            </h2>
            <p className="text-muted-foreground mb-6">
              Start shortening your links like magic today
            </p>
            {!session && (
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => router.push("/auth/signup")}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8 py-3 rounded-lg"
                >
                  Sign Up Free
                  <ArrowRight className="h-4 w-4 mr-2" />
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => signIn()}
                  className="border-border hover:bg-muted/50 font-semibold px-8 py-3 rounded-lg"
                >
                  Sign In to Account
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <Button
          onClick={scrollToTop}
          size="sm"
          className="fixed bottom-6 right-6 z-50 bg-primary hover:bg-primary/90 text-primary-foreground rounded-full shadow-lg"
        >
          <ArrowUp className="h-4 w-4" />
        </Button>
      )}
    </div>
  )
}