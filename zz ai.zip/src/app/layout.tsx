import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { SessionProvider } from "@/components/providers/session-provider";
import { ThemeProvider } from "next-themes";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "LinkFlow - The Future of URL Shortening",
  description: "Experience the most powerful, beautiful, and intelligent URL shortener with advanced analytics and seamless sharing.",
  keywords: ["URL shortener", "link shortener", "analytics", "link management", "URL redirection"],
  authors: [{ name: "LinkFlow Team" }],
  openGraph: {
    title: "LinkFlow - The Future of URL Shortening",
    description: "Transform your links into magic with the most advanced URL shortener",
    url: "https://linkflow.app",
    siteName: "LinkFlow",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "LinkFlow - The Future of URL Shortening",
    description: "Transform your links into magic with the most advanced URL shortener",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} font-sans antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <SessionProvider>
            {children}
            <Toaster />
          </SessionProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
