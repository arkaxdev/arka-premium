"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { 
  Loader2, 
  AlertCircle, 
  CheckCircle,
  Link as LinkIcon,
  Timer,
  XCircle,
  Sparkles
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

export default function RedirectPage({ params }: { params: Promise<{ code: string }> }) {
  const router = useRouter()
  const [status, setStatus] = useState<"loading" | "redirecting" | "error" | "expired" | "maxClicks">("loading")
  const [errorMessage, setErrorMessage] = useState("")
  const [countdown, setCountdown] = useState(3)

  useEffect(() => {
    const redirect = async () => {
      try {
        const { code } = await params
        const response = await fetch(`/api/redirect/${code}`)
        
        if (response.redirected) {
          setStatus("redirecting")
          // Start countdown
          const timer = setInterval(() => {
            setCountdown((prev) => {
              if (prev <= 1) {
                clearInterval(timer)
                window.location.href = response.url
                return 0
              }
              return prev - 1
            })
          }, 1000)
        } else {
          const data = await response.json()
          
          if (response.status === 404) {
            setStatus("error")
            setErrorMessage("Link not found")
          } else if (response.status === 410) {
            if (data.error === "Link has expired") {
              setStatus("expired")
              setErrorMessage("This link has expired")
            } else if (data.error === "Link has reached maximum clicks") {
              setStatus("maxClicks")
              setErrorMessage("This link has reached the maximum number of allowed clicks")
            }
          } else if (data.redirect) {
            // Redirect to ads page
            window.location.href = data.redirect
          } else {
            setStatus("error")
            setErrorMessage("An error occurred during redirect")
          }
        }
      } catch (error) {
        setStatus("error")
        setErrorMessage("Error connecting to server")
      }
    }

    redirect()
  }, [params])

  const renderContent = () => {
    switch (status) {
      case "loading":
        return (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-16 h-16 border-4 border-transparent border-t-primary rounded-full mx-auto mb-6"
            />
            <h2 className="text-2xl font-bold mb-2 text-foreground">
              Checking link...
            </h2>
            <p className="text-muted-foreground">
              Please wait a moment
            </p>
          </motion.div>
        )
      
      case "redirecting":
        return (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 10 }}
            >
              <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-10 w-10 text-green-600" />
              </div>
            </motion.div>
            <h2 className="text-2xl font-bold mb-2 text-foreground">
              Redirecting to destination...
            </h2>
            <p className="text-muted-foreground mb-6">
              You will be redirected in {countdown} seconds
            </p>
            <Progress 
              value={(countdown / 3) * 100} 
              className="h-2"
            />
            <div className="mt-6 flex items-center justify-center space-x-2 text-sm text-muted-foreground">
              <Sparkles className="h-4 w-4 text-primary" />
              <span>Preparing your destination</span>
            </div>
          </motion.div>
        )
      
      case "error":
        return (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 10 }}
            >
              <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <XCircle className="h-10 w-10 text-destructive" />
              </div>
            </motion.div>
            <h2 className="text-2xl font-bold mb-2 text-foreground">
              Error
            </h2>
            <p className="text-muted-foreground">
              {errorMessage}
            </p>
          </motion.div>
        )
      
      case "expired":
        return (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 10 }}
            >
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Timer className="h-10 w-10 text-primary" />
              </div>
            </motion.div>
            <h2 className="text-2xl font-bold mb-2 text-foreground">
              Link Expired
            </h2>
            <p className="text-muted-foreground">
              {errorMessage}
            </p>
          </motion.div>
        )
      
      case "maxClicks":
        return (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 10 }}
            >
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="h-10 w-10 text-primary" />
              </div>
            </motion.div>
            <h2 className="text-2xl font-bold mb-2 text-foreground">
              Click Limit Reached
            </h2>
            <p className="text-muted-foreground">
              {errorMessage}
            </p>
          </motion.div>
        )
      
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      {/* Logo */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute top-8 left-8"
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <LinkIcon className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">
            LinkFlow
          </h1>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
      >
        <Card className="w-full max-w-md bg-card border-border shadow-xl">
          <CardContent className="p-8">
            {renderContent()}
            
            {(status === "error" || status === "expired" || status === "maxClicks") && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="mt-8 text-center"
              >
                <Button
                  onClick={() => router.push("/")}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <LinkIcon className="h-4 w-4 mr-2" />
                  Back to Home
                </Button>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
