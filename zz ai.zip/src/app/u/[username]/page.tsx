"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { 
  User, 
  Mail, 
  Globe, 
  MessageCircle, 
  Share2, 
  ExternalLink,
  Calendar,
  Link as LinkIcon,
  Copy,
  Check,
  Instagram,
  Telegram,
  Facebook,
  Linkedin
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"

interface UserProfile {
  id: string
  name?: string
  username: string
  email?: string
  bio?: string
  avatar?: string
  isVIP: boolean
  telegram?: string
  instagram?: string
  facebook?: string
  linkedin?: string
  createdAt: string
  links: Array<{
    id: string
    originalUrl: string
    shortCode: string
    customSlug?: string
    title?: string
    description?: string
    createdAt: string
    clicks: Array<{
      id: string
      createdAt: string
    }>
  }>
}

export default function UserProfile() {
  const params = useParams()
  const username = params.username as string
  const [user, setUser] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [copiedLink, setCopiedLink] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    fetchUserProfile()
  }, [username])

  const fetchUserProfile = async () => {
    try {
      const response = await fetch(`/api/users/${username}`)
      if (response.ok) {
        const data = await response.json()
        setUser(data)
      } else {
        setUser(null)
      }
    } catch (error) {
      console.error("Error fetching user profile:", error)
      setUser(null)
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedLink(type)
      toast({
        title: "Copied",
        description: `${type} copied to clipboard`,
      })
      setTimeout(() => setCopiedLink(null), 2000)
    } catch (error) {
      toast({
        title: "Error",
        description: "Error copying to clipboard",
        variant: "destructive",
      })
    }
  }

  const getSocialIcon = (platform: string) => {
    switch (platform) {
      case 'telegram':
        return <Telegram className="h-5 w-5" />
      case 'instagram':
        return <Instagram className="h-5 w-5" />
      case 'facebook':
        return <Facebook className="h-5 w-5" />
      case 'linkedin':
        return <Linkedin className="h-5 w-5" />
      default:
        return <Globe className="h-5 w-5" />
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-300">Loading profile...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700 max-w-md">
          <CardContent className="p-8 text-center">
            <User className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">User Not Found</h2>
            <p className="text-gray-400 mb-4">
              No user found with username "{username}"
            </p>
            <Button onClick={() => window.location.href = "/"}>
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="border-b border-gray-700 bg-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <LinkIcon className="h-8 w-8 text-blue-400" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                User Profile
              </h1>
            </div>
            <Button 
              variant="ghost" 
              onClick={() => copyToClipboard(`${baseUrl}/u/${user.username}`, "Profile Link")}
            >
              {copiedLink === "Profile Link" ? <Check className="h-4 w-4" /> : <Share2 className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Profile Header */}
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700 mb-8">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8">
                <div className="flex-shrink-0">
                  <Avatar className="w-32 h-32">
                    <AvatarImage src={user.avatar} alt={user.name || user.username} />
                    <AvatarFallback className="text-2xl bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                      {(user.name || user.username).charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
                
                <div className="flex-1 text-center md:text-left">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                    <div>
                      <h2 className="text-3xl font-bold mb-2">
                        {user.name || user.username}
                      </h2>
                      <div className="flex items-center justify-center md:justify-start space-x-2">
                        <span className="text-gray-400">@{user.username}</span>
                        {user.isVIP && (
                          <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                            VIP
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0">
                      <p className="text-sm text-gray-400">
                        Member since {new Date(user.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {user.bio && (
                    <p className="text-gray-300 mb-6 leading-relaxed">
                      {user.bio}
                    </p>
                  )}

                  {/* Social Links */}
                  <div className="flex flex-wrap justify-center md:justify-start gap-3 mb-6">
                    {user.telegram && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`https://t.me/${user.telegram}`, "_blank")}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <Telegram className="h-4 w-4 ml-2" />
                        Telegram
                      </Button>
                    )}
                    {user.instagram && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`https://instagram.com/${user.instagram}`, "_blank")}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <Instagram className="h-4 w-4 ml-2" />
                        Instagram
                      </Button>
                    )}
                    {user.facebook && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`https://facebook.com/${user.facebook}`, "_blank")}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <Facebook className="h-4 w-4 ml-2" />
                        Facebook
                      </Button>
                    )}
                    {user.linkedin && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`https://linkedin.com/in/${user.linkedin}`, "_blank")}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <Linkedin className="h-4 w-4 ml-2" />
                        LinkedIn
                      </Button>
                    )}
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">
                        {user.links.length}
                      </div>
                      <div className="text-sm text-gray-400">Links</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">
                        {user.links.reduce((acc, link) => acc + link.clicks.length, 0)}
                      </div>
                      <div className="text-sm text-gray-400">Clicks</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-400">
                        {user.links.filter(link => link.clicks.length > 0).length}
                      </div>
                      <div className="text-sm text-gray-400">Active Links</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Links */}
          <Tabs defaultValue="links" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-gray-800">
              <TabsTrigger value="links" className="data-[state=active]:bg-blue-600">
                Links
              </TabsTrigger>
              <TabsTrigger value="about" className="data-[state=active]:bg-blue-600">
                About
              </TabsTrigger>
            </TabsList>

            <TabsContent value="links" className="mt-6">
              <div className="grid gap-4">
                {user.links.length === 0 ? (
                  <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
                    <CardContent className="p-8 text-center">
                      <LinkIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-bold mb-2">No Links Found</h3>
                      <p className="text-gray-400">
                        This user hasn't created any links yet
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  user.links.map((link) => (
                    <Card key={link.id} className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:border-gray-600 transition-colors">
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <LinkIcon className="h-5 w-5 text-blue-400" />
                              <h3 className="font-semibold text-lg">
                                {link.title || "Untitled Link"}
                              </h3>
                              <Badge variant="secondary">
                                {link.clicks.length} clicks
                              </Badge>
                            </div>
                            {link.description && (
                              <p className="text-gray-400 text-sm mb-2">
                                {link.description}
                              </p>
                            )}
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              <span className="font-mono">
                                {baseUrl}/{link.customSlug || link.shortCode}
                              </span>
                              <span>
                                {new Date(link.createdAt).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => copyToClipboard(`${baseUrl}/${link.customSlug || link.shortCode}`, "Short Link")}
                            >
                              {copiedLink === "Short Link" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => window.open(link.originalUrl, "_blank")}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="about" className="mt-6">
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
                <CardHeader>
                  <CardTitle>About User</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-gray-400">Username</label>
                      <p className="font-medium">@{user.username}</p>
                    </div>
                    {user.name && (
                      <div>
                        <label className="text-sm text-gray-400">Full Name</label>
                        <p className="font-medium">{user.name}</p>
                      </div>
                    )}
                    {user.email && (
                      <div>
                        <label className="text-sm text-gray-400">Email</label>
                        <p className="font-medium">{user.email}</p>
                      </div>
                    )}
                    <div>
                      <label className="text-sm text-gray-400">Join Date</label>
                      <p className="font-medium">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {user.bio && (
                    <div>
                      <label className="text-sm text-gray-400">Bio</label>
                      <p className="text-gray-300 mt-1">{user.bio}</p>
                    </div>
                  )}

                  <div>
                    <label className="text-sm text-gray-400">Account Status</label>
                    <div className="mt-1">
                      {user.isVIP ? (
                        <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                          VIP Member
                        </Badge>
                      ) : (
                        <Badge variant="secondary">Free Member</Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}