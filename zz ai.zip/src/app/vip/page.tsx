"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { 
  Crown, 
  Star, 
  Check, 
  X, 
  Zap, 
  Infinity, 
  Shield,
  TrendingUp,
  Gift,
  CreditCard,
  ArrowRight
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"

export default function VIPPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState("monthly")

  useEffect(() => {
    if (status === "loading") return
    
    if (!session) {
      router.push("/auth/signin")
    }
  }, [session, status, router])

  const handleUpgrade = async () => {
    setIsLoading(true)
    try {
      // In a real application, this would integrate with a payment processor
      // For now, we'll simulate the upgrade process
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      toast({
        title: "Success",
        description: "Your VIP subscription has been activated successfully",
      })
      
      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      toast({
        title: "Error",
        description: "Error processing request",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const plans = [
    {
      id: "monthly",
      name: "Monthly",
      price: "$9.99",
      originalPrice: "$14.99",
      period: "per month",
      features: [
        "Unlimited links",
        "No ads",
        "Advanced analytics",
        "Custom profile",
        "24/7 support",
        "Custom QR codes",
        "API access"
      ],
      popular: false
    },
    {
      id: "yearly",
      name: "Yearly",
      price: "$99.99",
      originalPrice: "$179.99",
      period: "per year",
      features: [
        "All monthly features",
        "2 months free",
        "Priority support",
        "Monthly reports",
        "Early access to new features",
        "Special discounts on future services"
      ],
      popular: true
    },
    {
      id: "lifetime",
      name: "Lifetime",
      price: "$299.99",
      originalPrice: null,
      period: "one-time payment",
      features: [
        "All yearly features",
        "Lifetime access",
        "No renewal needed",
        "Premium support",
        "Access to all future features",
        "Exclusive VIP username"
      ],
      popular: false
    }
  ]

  const vipFeatures = [
    {
      icon: Infinity,
      title: "Unlimited Links",
      description: "Create unlimited short links without any restrictions"
    },
    {
      icon: Shield,
      title: "Ad-Free Experience",
      description: "Your links redirect directly without displaying any ads"
    },
    {
      icon: TrendingUp,
      title: "Advanced Analytics",
      description: "Access detailed statistics and advanced click analytics"
    },
    {
      icon: Star,
      title: "Professional Profile",
      description: "Custom profile with custom URL and special features"
    },
    {
      icon: Zap,
      title: "High Speed",
      description: "Faster redirection speed and better reliability for your links"
    },
    {
      icon: Gift,
      title: "Exclusive Features",
      description: "Access to exclusive features and premium capabilities"
    }
  ]

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-300">Loading...</p>
        </div>
      </div>
    )
  }

  if (!session) {
    return null
  }

  const isVIP = session.user?.isVIP

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="border-b border-gray-700 bg-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Crown className="h-8 w-8 text-yellow-400" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                VIP Subscription
              </h1>
            </div>
            <Button variant="ghost" onClick={() => router.push("/dashboard")}>
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-4">
              <div className="relative">
                <Crown className="h-16 w-16 text-yellow-400" />
                <div className="absolute -top-2 -right-2">
                  <Star className="h-6 w-6 text-orange-400 fill-current" />
                </div>
              </div>
            </div>
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
              {isVIP ? "VIP Active" : "Upgrade to VIP"}
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              {isVIP 
                ? "You are now a VIP user and enjoy all the exclusive features"
                : "Upgrade to VIP and enjoy all the exclusive features and professional capabilities"
              }
            </p>
            {isVIP && (
              <Alert className="bg-green-500/20 border-green-500/30 max-w-md mx-auto">
                <Check className="h-4 w-4" />
                <AlertDescription className="text-green-300">
                  Your VIP subscription is active
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* VIP Features */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {vipFeatures.map((feature, index) => (
              <Card key={index} className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:border-yellow-500/50 transition-colors">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <feature.icon className="h-6 w-6 text-yellow-400 ml-2" />
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Pricing Plans */}
          {!isVIP && (
            <div className="mb-12">
              <h3 className="text-3xl font-bold text-center mb-8">Choose Your Plan</h3>
              <div className="grid md:grid-cols-3 gap-6">
                {plans.map((plan) => (
                  <Card 
                    key={plan.id} 
                    className={`bg-gray-800/50 backdrop-blur-sm border-gray-700 relative ${
                      plan.popular ? 'border-yellow-500/50 ring-2 ring-yellow-500/20' : ''
                    }`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                          Most Popular
                        </Badge>
                      </div>
                    )}
                    <CardHeader className="text-center">
                      <CardTitle className="text-xl">{plan.name}</CardTitle>
                      <div className="space-y-2">
                        <div className="flex items-center justify-center space-x-2">
                          <span className="text-3xl font-bold">{plan.price}</span>
                          <span className="text-gray-400">{plan.period}</span>
                        </div>
                        {plan.originalPrice && (
                          <div className="flex items-center justify-center space-x-2">
                            <span className="text-sm text-gray-400 line-through">{plan.originalPrice}</span>
                            <Badge variant="secondary" className="bg-green-500/20 text-green-300">
                              Save
                            </Badge>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <ul className="space-y-2">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-center text-sm">
                            <Check className="h-4 w-4 text-green-400 ml-2 flex-shrink-0" />
                            <span className="text-gray-300">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <Button 
                        className={`w-full ${
                          plan.popular 
                            ? 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600' 
                            : 'bg-gray-700 hover:bg-gray-600'
                        }`}
                        onClick={() => {
                          setSelectedPlan(plan.id)
                          handleUpgrade()
                        }}
                        disabled={isLoading}
                      >
                        {isLoading && selectedPlan === plan.id ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mx-auto" />
                        ) : (
                          <>
                            Upgrade to VIP
                            <ArrowRight className="h-4 w-4 ml-2" />
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Comparison */}
          <div className="mb-12">
            <h3 className="text-3xl font-bold text-center mb-8">Plan Comparison</h3>
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
              <CardContent className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-700">
                        <th className="text-right py-3 px-4">Feature</th>
                        <th className="text-center py-3 px-4">Free</th>
                        <th className="text-center py-3 px-4">VIP</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-gray-700">
                        <td className="py-3 px-4">Number of Links</td>
                        <td className="text-center py-3 px-4">50 links</td>
                        <td className="text-center py-3 px-4">
                          <Badge className="bg-green-500/20 text-green-300">Unlimited</Badge>
                        </td>
                      </tr>
                      <tr className="border-b border-gray-700">
                        <td className="py-3 px-4">Ads</td>
                        <td className="text-center py-3 px-4">
                          <Badge variant="secondary">With Ads</Badge>
                        </td>
                        <td className="text-center py-3 px-4">
                          <Badge className="bg-green-500/20 text-green-300">Ad-Free</Badge>
                        </td>
                      </tr>
                      <tr className="border-b border-gray-700">
                        <td className="py-3 px-4">Detailed Analytics</td>
                        <td className="text-center py-3 px-4">
                          <X className="h-4 w-4 text-red-400 mx-auto" />
                        </td>
                        <td className="text-center py-3 px-4">
                          <Check className="h-4 w-4 text-green-400 mx-auto" />
                        </td>
                      </tr>
                      <tr className="border-b border-gray-700">
                        <td className="py-3 px-4">Custom Profile</td>
                        <td className="text-center py-3 px-4">
                          <X className="h-4 w-4 text-red-400 mx-auto" />
                        </td>
                        <td className="text-center py-3 px-4">
                          <Check className="h-4 w-4 text-green-400 mx-auto" />
                        </td>
                      </tr>
                      <tr className="border-b border-gray-700">
                        <td className="py-3 px-4">Support</td>
                        <td className="text-center py-3 px-4">Standard</td>
                        <td className="text-center py-3 px-4">
                          <Badge className="bg-yellow-500/20 text-yellow-300">24/7</Badge>
                        </td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4">API Access</td>
                        <td className="text-center py-3 px-4">
                          <X className="h-4 w-4 text-red-400 mx-auto" />
                        </td>
                        <td className="text-center py-3 px-4">
                          <Check className="h-4 w-4 text-green-400 mx-auto" />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* FAQ */}
          <div>
            <h3 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">How do I upgrade to VIP?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Simply choose one of the VIP plans and complete the payment. Your subscription will be activated automatically.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">Can I cancel my subscription?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Yes, you can cancel your subscription at any time. Your VIP access will remain until the end of your paid period.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">What's the difference between VIP and Free?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    VIP users get access to premium features like unlimited links, no ads, advanced analytics, custom profiles, and priority support.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">Is payment secure?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Yes, we use industry-standard encryption and secure payment processors to ensure your payment information is safe.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}