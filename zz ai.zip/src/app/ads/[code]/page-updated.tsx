"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useParams } from "next/navigation"
import { motion } from "framer-motion"
import { 
  ExternalLink, 
  SkipForward, 
  Timer, 
  Megaphone,
  AlertCircle,
  CheckCircle,
  Link as LinkIcon,
  Shield,
  Sparkles
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function AdsPage() {
  const params = useParams()
  const code = params.code as string
  const router = useRouter()
  const [countdown, setCountdown] = useState(10)
  const [adData, setAdData] = useState<any>(null)
  const [linkData, setLinkData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    fetchAdAndLinkData()
  }, [code])

  useEffect(() => {
    if (countdown > 0 && !isLoading && !error) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000)
      return () => clearTimeout(timer)
    } else if (countdown === 0 && !error) {
      redirectToDestination()
    }
  }, [countdown, isLoading, error])

  const fetchAdAndLinkData = async () => {
    try {
      // Fetch link data
      const linkResponse = await fetch(`/api/redirect/${code}`)
      if (!linkResponse.ok) {
        const errorData = await linkResponse.json()
        setError(errorData.error || "Link not found")
        setIsLoading(false)
        return
      }

      const linkData = await linkResponse.json()
      setLinkData(linkData)

      // If no ads for this link, redirect immediately
      if (!linkData.showAds) {
        redirectToDestination()
        return
      }

      // Fetch random ad
      const adResponse = await fetch("/api/ads/random")
      if (adResponse.ok) {
        const adData = await adResponse.json()
        setAdData(adData)
      }

      setIsLoading(false)
    } catch (error) {
      setError("Error loading page")
      setIsLoading(false)
    }
  }

  const redirectToDestination = () => {
    if (linkData?.originalUrl) {
      // Record ad impression
      if (adData?.id) {
        fetch(`/api/ads/${adData.id}/impression`, { method: "POST" })
      }
      window.location.href = linkData.originalUrl
    }
  }

  const skipAd = () => {
    redirectToDestination()
  }

  const handleAdClick = () => {
    if (adData?.id) {
      fetch(`/api/ads/${adData.id}/click`, { method: "POST" })
    }
    if (adData?.targetUrl) {
      window.open(adData.targetUrl, "_blank")
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-16 h-16 border-4 border-transparent border-t-primary rounded-full mx-auto"
          />
          <p className="mt-4 text-muted-foreground text-lg">Loading...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="w-full max-w-md bg-card border-border shadow-xl">
            <CardContent className="p-8 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 10 }}
              >
                <AlertCircle className="h-16 w-16 text-destructive mx-auto mb-4" />
              </motion.div>
              <h2 className="text-2xl font-bold mb-2 text-foreground">Error</h2>
              <p className="text-muted-foreground mb-6">{error}</p>
              <Button 
                onClick={() => router.push("/")}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Back to Home
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-3"
            >
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <LinkIcon className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  LinkFlow
                </h1>
                <p className="text-sm text-muted-foreground">Redirecting you shortly</p>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-4"
            >
              <div className="flex items-center space-x-2 text-sm">
                <Timer className="h-4 w-4 text-primary" />
                <span className="font-medium text-foreground">{countdown}s</span>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={skipAd}
                className="border-border hover:bg-muted/50"
                disabled={countdown > 5}
              >
                <SkipForward className="h-4 w-4 mr-2" />
                {countdown > 5 ? `Wait ${countdown - 5}s` : 'Skip Ad'}
              </Button>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Progress Bar */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">
                <Sparkles className="inline h-4 w-4 mr-1 text-primary" />
                Redirecting to your destination
              </span>
              <span className="text-sm font-medium text-foreground">{countdown}s remaining</span>
            </div>
            <Progress 
              value={((10 - countdown) / 10) * 100} 
              className="h-2"
            />
          </motion.div>

          {/* Ad Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-card border-border shadow-xl overflow-hidden">
              <CardContent className="p-0">
                {adData ? (
                  <div 
                    className="cursor-pointer hover:opacity-95 transition-opacity"
                    onClick={handleAdClick}
                  >
                    {adData.imageUrl && (
                      <div className="relative">
                        <img 
                          src={adData.imageUrl} 
                          alt={adData.title}
                          className="w-full h-80 object-cover"
                        />
                        <div className="absolute top-4 right-4">
                          <Badge className="bg-primary text-primary-foreground border-0">
                            <Megaphone className="h-3 w-3 mr-1" />
                            Advertisement
                          </Badge>
                        </div>
                      </div>
                    )}
                    <div className="p-8">
                      <h2 className="text-3xl font-bold mb-3 text-foreground">
                        {adData.title}
                      </h2>
                      <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                        {adData.content}
                      </p>
                      <div className="flex items-center justify-between">
                        <Button 
                          variant="outline"
                          className="border-border hover:bg-muted/50"
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Learn More
                        </Button>
                        <span className="text-sm text-muted-foreground">
                          Click to visit advertiser's website
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-16 text-center">
                    <motion.div
                      animate={{ 
                        scale: [1, 1.1, 1],
                        rotate: [0, 5, -5, 0]
                      }}
                      transition={{ 
                        duration: 2,
                        repeat: Infinity,
                        repeatType: "reverse"
                      }}
                    >
                      <Megaphone className="h-20 w-20 text-muted-foreground/50 mx-auto mb-6" />
                    </motion.div>
                    <h2 className="text-2xl font-bold mb-3 text-foreground">
                      Advertisement Space
                    </h2>
                    <p className="text-muted-foreground max-w-md mx-auto">
                      Please wait a few seconds while we redirect you to your destination
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Info Cards */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-8 grid md:grid-cols-2 gap-4"
          >
            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center">
                    <Shield className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">Secure Link</p>
                    <p className="text-sm text-muted-foreground">
                      This link has been verified by our system
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                    <Timer className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">Auto Redirect</p>
                    <p className="text-sm text-muted-foreground">
                      You will be redirected in {countdown} seconds
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
    </div>
  )
}
