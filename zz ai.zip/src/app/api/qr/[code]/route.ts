import { NextRequest, NextResponse } from "next/server"
import QRCode from "qrcode"
import { db } from "@/lib/db"

export async function GET(
  request: NextRequest,
  { params }: { params: { code: string } }
) {
  try {
    const { code } = params
    const { searchParams } = new URL(request.url)
    const color = searchParams.get("color") || "#000000"
    const background = searchParams.get("background") || "#FFFFFF"

    // Find the link
    const link = await db.link.findFirst({
      where: {
        OR: [
          { shortCode: code },
          { customSlug: code }
        ],
        isActive: true
      }
    })

    if (!link) {
      return NextResponse.json(
        { error: "Link not found" },
        { status: 404 }
      )
    }

    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"
    const url = `${baseUrl}/${link.customSlug || link.shortCode}`

    // Generate QR code
    const qrCode = await QRCode.toDataURL(url, {
      color: {
        dark: color,
        light: background
      },
      width: 300,
      margin: 2,
      errorCorrectionLevel: 'M'
    })

    // Update link with QR code if not already set
    if (!link.qrCode) {
      await db.link.update({
        where: { id: link.id },
        data: { qrCode }
      })
    }

    return NextResponse.json({
      qrCode,
      url,
      shortCode: link.shortCode,
      customSlug: link.customSlug
    })

  } catch (error) {
    console.error("Error generating QR code:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}