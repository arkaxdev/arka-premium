import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { nanoid } from "nanoid"

export async function POST(request: NextRequest) {
  try {
    const { url, customSlug } = await request.json()

    if (!url) {
      return NextResponse.json(
        { error: "URL is required" },
        { status: 400 }
      )
    }

    // Validate URL
    try {
      new URL(url)
    } catch {
      return NextResponse.json(
        { error: "Invalid URL" },
        { status: 400 }
      )
    }

    // Check if custom slug is already taken
    if (customSlug) {
      const existingLink = await db.link.findUnique({
        where: { customSlug }
      })

      if (existingLink) {
        return NextResponse.json(
          { error: "Custom slug is already taken" },
          { status: 400 }
        )
      }
    }

    // Generate short code
    const shortCode = customSlug || nanoid(8)

    // Create the link
    const link = await db.link.create({
      data: {
        originalUrl: url,
        shortCode,
        customSlug: customSlug || null,
      }
    })

    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"
    const shortUrl = `${baseUrl}/${shortCode}`

    return NextResponse.json({
      shortUrl,
      shortCode,
      id: link.id
    })

  } catch (error) {
    console.error("Error shortening URL:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}