import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const ad = await db.advertisement.update({
      where: { id: params.id },
      data: {
        clicks: {
          increment: 1
        }
      }
    })

    return NextResponse.json({ success: true, clicks: ad.clicks })

  } catch (error) {
    console.error("Error recording ad click:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}