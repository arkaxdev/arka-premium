import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const ad = await db.advertisement.update({
      where: { id: params.id },
      data: {
        impressions: {
          increment: 1
        }
      }
    })

    return NextResponse.json({ success: true, impressions: ad.impressions })

  } catch (error) {
    console.error("Error recording ad impression:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}