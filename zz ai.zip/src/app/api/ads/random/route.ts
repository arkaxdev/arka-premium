import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    // Get a random active ad
    const ads = await db.advertisement.findMany({
      where: { 
        isActive: true,
        position: "interstitial"
      },
      orderBy: { createdAt: "desc" }
    })

    if (ads.length === 0) {
      return NextResponse.json({ error: "No ads available" }, { status: 404 })
    }

    // Select a random ad
    const randomAd = ads[Math.floor(Math.random() * ads.length)]

    return NextResponse.json(randomAd)

  } catch (error) {
    console.error("Error fetching random ad:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}