import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { db } from "@/lib/db"
import { nanoid } from "nanoid"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const links = await db.link.findMany({
      where: {
        userId: session.user.id
      },
      include: {
        clicks: {
          orderBy: {
            createdAt: "desc"
          }
        }
      },
      orderBy: {
        createdAt: "desc"
      }
    })

    return NextResponse.json(links)

  } catch (error) {
    console.error("Error fetching links:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const { url, customSlug, title, description, password, expiresAt, maxClicks, showAds } = await request.json()

    if (!url) {
      return NextResponse.json(
        { error: "URL is required" },
        { status: 400 }
      )
    }

    // Validate URL
    try {
      new URL(url)
    } catch {
      return NextResponse.json(
        { error: "Invalid URL" },
        { status: 400 }
      )
    }

    // Check if custom slug is already taken
    if (customSlug) {
      const existingLink = await db.link.findFirst({
        where: {
          OR: [
            { customSlug },
            { shortCode: customSlug }
          ]
        }
      })

      if (existingLink) {
        return NextResponse.json(
          { error: "Custom slug is already taken" },
          { status: 400 }
        )
      }
    }

    // Check user limits (non-VIP users have limits)
    const user = await db.user.findUnique({
      where: { id: session.user.id }
    })

    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        { status: 404 }
      )
    }

    const userLinksCount = await db.link.count({
      where: { userId: session.user.id }
    })

    if (!user.isVIP && userLinksCount >= 50) {
      return NextResponse.json(
        { error: "You have reached the maximum number of links. Upgrade to VIP for unlimited links." },
        { status: 403 }
      )
    }

    // Generate short code
    const shortCode = customSlug || nanoid(8)

    // Create the link
    const link = await db.link.create({
      data: {
        originalUrl: url,
        shortCode,
        customSlug: customSlug || null,
        title: title || null,
        description: description || null,
        password: password || null,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        maxClicks: maxClicks || null,
        showAds: showAds ?? true,
        userId: session.user.id,
      },
      include: {
        clicks: true
      }
    })

    return NextResponse.json(link)

  } catch (error) {
    console.error("Error creating link:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}