import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { db } from "@/lib/db"

export async function POST(
  request: NextRequest,
  { params }: { params: { userId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user?.role !== "ADMIN") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { id: params.userId }
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const updatedUser = await db.user.update({
      where: { id: params.userId },
      data: { 
        role: user.role === "VIP" ? "FREE" : "VIP",
        subscriptionEnds: user.role === "FREE" ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) : null
      }
    })

    return NextResponse.json({ 
      message: "User VIP status updated successfully",
      role: updatedUser.role 
    })
  } catch (error) {
    console.error("Error toggling user VIP status:", error)
    return NextResponse.json({ error: "Failed to update user VIP status" }, { status: 500 })
  }
}