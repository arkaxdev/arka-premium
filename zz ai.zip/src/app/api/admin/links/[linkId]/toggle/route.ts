import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { db } from "@/lib/db"

async function isAdmin(request: NextRequest) {
  const session = await getServerSession(authOptions)
  return session?.user?.email === "admin@example.com"
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { linkId: string } }
) {
  if (!(await isAdmin(request))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { isActive } = await request.json()

    const link = await db.link.update({
      where: { id: params.linkId },
      data: { isActive }
    })

    return NextResponse.json(link)
  } catch (error) {
    console.error("Error toggling link status:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}