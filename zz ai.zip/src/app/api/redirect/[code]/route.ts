import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET(
  request: NextRequest,
  { params }: { params: { code: string } }
) {
  try {
    const { code } = params

    // Find the link by short code or custom slug
    const link = await db.link.findFirst({
      where: {
        OR: [
          { shortCode: code },
          { customSlug: code }
        ],
        isActive: true
      }
    })

    if (!link) {
      return NextResponse.json(
        { error: "Link not found" },
        { status: 404 }
      )
    }

    // Check if link is expired
    if (link.expiresAt && new Date() > link.expiresAt) {
      return NextResponse.json(
        { error: "Link has expired" },
        { status: 410 }
      )
    }

    // Check if max clicks reached
    if (link.maxClicks) {
      const clickCount = await db.click.count({
        where: { linkId: link.id }
      })

      if (clickCount >= link.maxClicks) {
        return NextResponse.json(
          { error: "Link has reached maximum clicks" },
          { status: 410 }
        )
      }
    }

    // Get client info
    const userAgent = request.headers.get("user-agent") || ""
    const ip = request.headers.get("x-forwarded-for") || 
                request.headers.get("x-real-ip") || 
                "unknown"
    
    // Simple browser and OS detection
    let browser = "unknown"
    let os = "unknown"
    let device = "desktop"

    if (userAgent.includes("Chrome")) browser = "chrome"
    else if (userAgent.includes("Firefox")) browser = "firefox"
    else if (userAgent.includes("Safari")) browser = "safari"
    else if (userAgent.includes("Edge")) browser = "edge"

    if (userAgent.includes("Windows")) os = "windows"
    else if (userAgent.includes("Mac")) os = "macos"
    else if (userAgent.includes("Linux")) os = "linux"
    else if (userAgent.includes("Android")) os = "android"
    else if (userAgent.includes("iPhone") || userAgent.includes("iPad")) os = "ios"

    if (userAgent.includes("Mobile") || userAgent.includes("Android") || userAgent.includes("iPhone")) {
      device = "mobile"
    } else if (userAgent.includes("iPad")) {
      device = "tablet"
    }

    // Check if we should show ads
    if (link.showAds) {
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"
      const adUrl = `${baseUrl}/ads/${code}`
      return NextResponse.json({
        redirect: adUrl,
        originalUrl: link.originalUrl,
        showAds: true
      })
    }

    // Record the click
    await db.click.create({
      data: {
        linkId: link.id,
        ip: ip.split(",")[0], // Get the first IP if there are multiple
        userAgent,
        browser,
        os,
        device,
        referer: request.headers.get("referer") || null,
      }
    })

    // Redirect to the original URL
    return NextResponse.redirect(link.originalUrl)

  } catch (error) {
    console.error("Error redirecting:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}