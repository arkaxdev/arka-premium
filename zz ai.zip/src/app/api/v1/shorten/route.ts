import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { db } from "@/lib/db"
import { nanoid } from "nanoid"

// Rate limiting middleware
async function checkRateLimit(request: NextRequest, apiKey: string) {
  // In production, implement proper rate limiting using Redis or similar
  // For now, we'll use a simple in-memory check
  const key = `rate_limit:${apiKey}`
  const now = Date.now()
  const windowStart = now - (60 * 1000) // 1 minute window
  
  // This is a simplified version - in production, use a proper rate limiting solution
  return true
}

export async function POST(request: NextRequest) {
  try {
    // Get API key from Authorization header
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { error: "Missing or invalid API key" },
        { status: 401 }
      )
    }

    const apiKey = authHeader.substring(7)
    
    // Find user by API key
    const user = await db.user.findFirst({
      where: { apiKey }
    })

    if (!user) {
      return NextResponse.json(
        { error: "Invalid API key" },
        { status: 401 }
      )
    }

    if (!user.isActive) {
      return NextResponse.json(
        { error: "Account is suspended" },
        { status: 403 }
      )
    }

    // Check rate limit
    if (!(await checkRateLimit(request, apiKey))) {
      return NextResponse.json(
        { error: "Rate limit exceeded" },
        { status: 429 }
      )
    }

    const { url, customSlug, title, description, password, expiresAt, maxClicks, showAds } = await request.json()

    if (!url) {
      return NextResponse.json(
        { error: "URL is required" },
        { status: 400 }
      )
    }

    // Validate URL
    try {
      new URL(url)
    } catch {
      return NextResponse.json(
        { error: "Invalid URL" },
        { status: 400 }
      )
    }

    // Check if custom slug is already taken
    if (customSlug) {
      const existingLink = await db.link.findFirst({
        where: {
          OR: [
            { customSlug },
            { shortCode: customSlug }
          ]
        }
      })

      if (existingLink) {
        return NextResponse.json(
          { error: "Custom slug is already taken" },
          { status: 400 }
        )
      }
    }

    // Check user limits
    const userLinksCount = await db.link.count({
      where: { userId: user.id }
    })

    if (!user.isVIP && userLinksCount >= 100) { // API users get higher limit
      return NextResponse.json(
        { error: "You have reached the maximum number of links. Upgrade to VIP for unlimited links." },
        { status: 403 }
      )
    }

    // Generate short code
    const shortCode = customSlug || nanoid(8)

    // Create the link
    const link = await db.link.create({
      data: {
        originalUrl: url,
        shortCode,
        customSlug: customSlug || null,
        title: title || null,
        description: description || null,
        password: password || null,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        maxClicks: maxClicks || null,
        showAds: showAds ?? true,
        userId: user.id,
      }
    })

    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"
    const shortUrl = `${baseUrl}/${link.customSlug || link.shortCode}`

    return NextResponse.json({
      id: link.id,
      shortUrl,
      shortCode: link.shortCode,
      customSlug: link.customSlug,
      originalUrl: link.originalUrl,
      createdAt: link.createdAt,
      expiresAt: link.expiresAt,
      maxClicks: link.maxClicks,
      showAds: link.showAds
    })

  } catch (error) {
    console.error("Error creating link via API:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}