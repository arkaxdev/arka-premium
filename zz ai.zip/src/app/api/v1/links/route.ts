import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { db } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    // Get API key from Authorization header
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { error: "Missing or invalid API key" },
        { status: 401 }
      )
    }

    const apiKey = authHeader.substring(7)
    
    // Find user by API key
    const user = await db.user.findFirst({
      where: { apiKey }
    })

    if (!user) {
      return NextResponse.json(
        { error: "Invalid API key" },
        { status: 401 }
      )
    }

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "20")
    const search = searchParams.get("search") || ""
    const sortBy = searchParams.get("sortBy") || "createdAt"
    const sortOrder = searchParams.get("sortOrder") || "desc"

    const offset = (page - 1) * limit

    // Build where clause
    const where = {
      userId: user.id,
      ...(search && {
        OR: [
          { originalUrl: { contains: search } },
          { title: { contains: search } },
          { description: { contains: search } },
          { customSlug: { contains: search } }
        ]
      })
    }

    // Get links with pagination
    const [links, total] = await Promise.all([
      db.link.findMany({
        where,
        include: {
          _count: {
            select: {
              clicks: true
            }
          }
        },
        orderBy: {
          [sortBy]: sortOrder
        },
        skip: offset,
        take: limit
      }),
      db.link.count({ where })
    ])

    return NextResponse.json({
      links: links.map(link => ({
        id: link.id,
        shortCode: link.shortCode,
        customSlug: link.customSlug,
        originalUrl: link.originalUrl,
        title: link.title,
        description: link.description,
        createdAt: link.createdAt,
        isActive: link.isActive,
        showAds: link.showAds,
        totalClicks: link._count.clicks
      })),
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })

  } catch (error) {
    console.error("Error fetching links:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}