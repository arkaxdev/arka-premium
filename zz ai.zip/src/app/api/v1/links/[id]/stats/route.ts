import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { db } from "@/lib/db"

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Get API key from Authorization header
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { error: "Missing or invalid API key" },
        { status: 401 }
      )
    }

    const apiKey = authHeader.substring(7)
    
    // Find user by API key
    const user = await db.user.findFirst({
      where: { apiKey }
    })

    if (!user) {
      return NextResponse.json(
        { error: "Invalid API key" },
        { status: 401 }
      )
    }

    // Find the link and verify ownership
    const link = await db.link.findFirst({
      where: {
        id: params.id,
        userId: user.id
      },
      include: {
        clicks: {
          orderBy: {
            createdAt: "desc"
          }
        }
      }
    })

    if (!link) {
      return NextResponse.json(
        { error: "Link not found or access denied" },
        { status: 404 }
      )
    }

    // Calculate stats
    const totalClicks = link.clicks.length
    const uniqueClicks = new Set(link.clicks.map(click => click.ip)).size
    const todayClicks = link.clicks.filter(click => {
      const clickDate = new Date(click.createdAt)
      const today = new Date()
      return clickDate.toDateString() === today.toDateString()
    }).length

    // Browser stats
    const browserStats = link.clicks.reduce((acc, click) => {
      const browser = click.browser || "unknown"
      acc[browser] = (acc[browser] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    // Device stats
    const deviceStats = link.clicks.reduce((acc, click) => {
      const device = click.device || "unknown"
      acc[device] = (acc[device] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    // Country stats
    const countryStats = link.clicks.reduce((acc, click) => {
      const country = click.country || "unknown"
      acc[country] = (acc[country] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    // Daily stats for the last 30 days
    const dailyStats = []
    for (let i = 29; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      date.setHours(0, 0, 0, 0)
      
      const nextDate = new Date(date)
      nextDate.setDate(nextDate.getDate() + 1)
      
      const dayClicks = link.clicks.filter(click => {
        const clickDate = new Date(click.createdAt)
        return clickDate >= date && clickDate < nextDate
      }).length

      dailyStats.push({
        date: date.toISOString().split('T')[0],
        clicks: dayClicks
      })
    }

    return NextResponse.json({
      link: {
        id: link.id,
        shortCode: link.shortCode,
        customSlug: link.customSlug,
        originalUrl: link.originalUrl,
        createdAt: link.createdAt,
        totalClicks,
        uniqueClicks,
        todayClicks,
        isActive: link.isActive,
        showAds: link.showAds
      },
      stats: {
        totalClicks,
        uniqueClicks,
        todayClicks,
        browserStats,
        deviceStats,
        countryStats,
        dailyStats
      },
      recentClicks: link.clicks.slice(0, 10).map(click => ({
        id: click.id,
        createdAt: click.createdAt,
        ip: click.ip,
        browser: click.browser,
        device: click.device,
        country: click.country,
        city: click.city
      }))
    })

  } catch (error) {
    console.error("Error fetching link stats:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}