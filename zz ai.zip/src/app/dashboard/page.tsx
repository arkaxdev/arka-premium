"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { 
  Link as LinkIcon, 
  Copy, 
  Trash2, 
  BarChart3, 
  Plus, 
  ExternalLink,
  Calendar,
  MousePointer,
  Settings,
  User,
  LogOut,
  Download,
  QrCode,
  Crown,
  Globe,
  Shield,
  Clock,
  Zap,
  Eye,
  Edit
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { signOut } from "next-auth/react"

interface Link {
  id: string
  originalUrl: string
  shortCode: string
  customSlug?: string
  title?: string
  description?: string
  password?: string
  expiresAt?: string
  maxClicks?: number
  showAds: boolean
  isActive: boolean
  createdAt: string
  clicks: Click[]
}

interface Click {
  id: string
  createdAt: string
  ip?: string
  browser?: string
  os?: string
  device?: string
  country?: string
  city?: string
}

export default function Dashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { toast } = useToast()
  const [links, setLinks] = useState<Link[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showStatsDialog, setShowStatsDialog] = useState(false)
  const [showQrDialog, setShowQrDialog] = useState(false)
  const [selectedLink, setSelectedLink] = useState<Link | null>(null)
  const [qrCodeImage, setQrCodeImage] = useState<string | null>(null)
  const [newLink, setNewLink] = useState({
    url: "",
    customSlug: "",
    title: "",
    description: "",
    password: "",
    expiresAt: "",
    maxClicks: "",
    showAds: true,
    redirectType: "DIRECT",
    splashContent: "",
    overlayContent: "",
    frameContent: "",
    utmSource: "",
    utmMedium: "",
    utmCampaign: "",
    utmTerm: "",
    utmContent: ""
  })

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/signin")
    } else if (status === "authenticated") {
      fetchLinks()
    }
  }, [status, router])

  const fetchLinks = async () => {
    try {
      const response = await fetch("/api/links")
      if (response.ok) {
        const data = await response.json()
        setLinks(data)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch links",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateLink = async () => {
    try {
      const response = await fetch("/api/links", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...newLink,
          maxClicks: newLink.maxClicks ? parseInt(newLink.maxClicks) : undefined,
          expiresAt: newLink.expiresAt || undefined,
        }),
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Link created successfully",
        })
        setShowCreateDialog(false)
        setNewLink({
          url: "",
          customSlug: "",
          title: "",
          description: "",
          password: "",
          expiresAt: "",
          maxClicks: "",
          showAds: true,
          redirectType: "DIRECT",
          splashContent: "",
          overlayContent: "",
          frameContent: "",
          utmSource: "",
          utmMedium: "",
          utmCampaign: "",
          utmTerm: "",
          utmContent: ""
        })
        fetchLinks()
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to create link",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to connect to server",
        variant: "destructive",
      })
    }
  }

  const handleDeleteLink = async (linkId: string) => {
    if (!confirm("Are you sure you want to delete this link?")) return

    try {
      const response = await fetch(`/api/links/${linkId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Link deleted successfully",
        })
        fetchLinks()
      } else {
        toast({
          title: "Error",
          description: "Failed to delete link",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to connect to server",
        variant: "destructive",
      })
    }
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Copied",
        description: "Link copied to clipboard",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy link",
        variant: "destructive",
      })
    }
  }

  const handleSignOut = () => {
    signOut({ callbackUrl: "/" })
  }

  const generateQRCode = async (link: Link) => {
    try {
      const response = await fetch(`/api/qr/${link.customSlug || link.shortCode}`)
      if (response.ok) {
        const data = await response.json()
        setQrCodeImage(data.qrCode)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate QR Code",
        variant: "destructive",
      })
    }
  }

  const downloadQRCode = () => {
    if (qrCodeImage) {
      const link = document.createElement('a')
      link.download = `qrcode-${selectedLink?.customSlug || selectedLink?.shortCode}.png`
      link.href = qrCodeImage
      link.click()
    }
  }

  useEffect(() => {
    if (selectedLink && showQrDialog) {
      setQrCodeImage(null)
      generateQRCode(selectedLink)
    }
  }, [selectedLink, showQrDialog])

  if (status === "loading" || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-transparent border-t-primary rounded-full mx-auto animate-spin"></div>
          <p className="mt-4 text-muted-foreground text-lg">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!session) {
    return null
  }

  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <LinkIcon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h1 className="text-2xl font-bold text-foreground">
                Dashboard
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{session.user?.name}</p>
                  <p className="text-xs text-muted-foreground">{session.user?.email}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {!session.user?.isVIP && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => router.push("/vip")}
                    className="border-amber-500/30 text-amber-600 dark:text-amber-400 hover:bg-amber-500/20 hover:text-amber-700 dark:hover:text-amber-300"
                  >
                    <Crown className="h-4 w-4 mr-2" />
                    Upgrade to VIP
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={handleSignOut} className="text-muted-foreground hover:text-foreground hover:bg-muted">
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-8">
          {/* Stats Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-card border-border hover:shadow-md transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Links</CardTitle>
                <Globe className="h-5 w-5 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{links.length}</div>
                <p className="text-xs text-muted-foreground mt-1">Active short links</p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border hover:shadow-md transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Clicks</CardTitle>
                <MousePointer className="h-5 w-5 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">
                  {links.reduce((acc, link) => acc + link.clicks.length, 0)}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Link visits</p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border hover:shadow-md transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Active Links</CardTitle>
                <Zap className="h-5 w-5 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">
                  {links.filter(link => link.isActive).length}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Currently active</p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border hover:shadow-md transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Account Status</CardTitle>
                <Badge variant={session.user?.isVIP ? "default" : "secondary"} className={session.user?.isVIP ? "bg-amber-500 text-black" : "bg-muted text-muted-foreground"}>
                  {session.user?.isVIP ? "VIP" : "Free"}
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">
                  {session.user?.isVIP ? "Premium User" : "Upgrade to VIP"}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Create Link Button */}
          <div className="flex justify-between items-center">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">My Links</h2>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-6 py-3 rounded-lg shadow-sm hover:shadow-md transition-all duration-300">
                  <Plus className="h-5 w-5 mr-2" />
                  Create New Link
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border text-foreground max-w-2xl max-h-[90vh] overflow-y-auto rounded-lg">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold text-foreground">Create New Link</DialogTitle>
                  <DialogDescription className="text-muted-foreground">
                    Shorten your URL and apply custom settings
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-6">
                  <div>
                    <Label htmlFor="url" className="text-foreground">Original URL</Label>
                    <Input
                      id="url"
                      value={newLink.url}
                      onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                      className="bg-background border-border text-foreground placeholder-muted-foreground focus:border-primary"
                      placeholder="https://example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="customSlug" className="text-foreground">Custom Slug (Optional)</Label>
                    <Input
                      id="customSlug"
                      value={newLink.customSlug}
                      onChange={(e) => setNewLink({ ...newLink, customSlug: e.target.value })}
                      className="bg-background border-border text-foreground placeholder-muted-foreground focus:border-primary"
                      placeholder="my-custom-link"
                    />
                  </div>
                  <div>
                    <Label htmlFor="title" className="text-foreground">Title (Optional)</Label>
                    <Input
                      id="title"
                      value={newLink.title}
                      onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                      className="bg-background border-border text-foreground placeholder-muted-foreground focus:border-primary"
                      placeholder="Link title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description" className="text-foreground">Description (Optional)</Label>
                    <Textarea
                      id="description"
                      value={newLink.description}
                      onChange={(e) => setNewLink({ ...newLink, description: e.target.value })}
                      className="bg-background border-border text-foreground placeholder-muted-foreground focus:border-primary"
                      placeholder="Link description"
                      rows={3}
                    />
                  </div>
                  <div className="flex justify-end space-x-3">
                    <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleCreateLink} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                      Create Link
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Links Table */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-foreground">Your Links</CardTitle>
              <CardDescription className="text-muted-foreground">
                Manage all your shortened links
              </CardDescription>
            </CardHeader>
            <CardContent>
              {links.length === 0 ? (
                <div className="text-center py-12">
                  <LinkIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No links yet</h3>
                  <p className="text-muted-foreground mb-4">Create your first short link to get started</p>
                  <Button onClick={() => setShowCreateDialog(true)} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Your First Link
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-foreground">Original URL</TableHead>
                        <TableHead className="text-foreground">Short URL</TableHead>
                        <TableHead className="text-foreground">Clicks</TableHead>
                        <TableHead className="text-foreground">Created</TableHead>
                        <TableHead className="text-foreground">Status</TableHead>
                        <TableHead className="text-foreground">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {links.map((link) => (
                        <TableRow key={link.id} className="hover:bg-muted/50">
                          <TableCell className="font-medium text-foreground max-w-xs truncate">
                            {link.title || link.originalUrl}
                          </TableCell>
                          <TableCell className="text-foreground">
                            <div className="flex items-center space-x-2">
                              <span className="text-sm text-primary">
                                {baseUrl}/{link.customSlug || link.shortCode}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-foreground">
                            <div className="flex items-center space-x-1">
                              <MousePointer className="h-4 w-4 text-muted-foreground" />
                              <span>{link.clicks.length}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {new Date(link.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant={link.isActive ? "default" : "secondary"}>
                              {link.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(`${baseUrl}/${link.customSlug || link.shortCode}`)}
                                className="text-muted-foreground hover:text-foreground"
                              >
                                <Copy className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => window.open(`${baseUrl}/${link.customSlug || link.shortCode}`, '_blank')}
                                className="text-muted-foreground hover:text-foreground"
                              >
                                <ExternalLink className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setSelectedLink(link)
                                  setShowQrDialog(true)
                                }}
                                className="text-muted-foreground hover:text-foreground"
                              >
                                <QrCode className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteLink(link.id)}
                                className="text-muted-foreground hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* QR Code Dialog */}
      <Dialog open={showQrDialog} onOpenChange={setShowQrDialog}>
        <DialogContent className="bg-card border-border text-foreground max-w-md rounded-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-foreground">QR Code</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Scan this QR code to visit your link
            </DialogDescription>
          </DialogHeader>
          {qrCodeImage ? (
            <div className="text-center space-y-4">
              <img src={qrCodeImage} alt="QR Code" className="w-48 h-48 mx-auto" />
              <div className="text-sm text-muted-foreground">
                {baseUrl}/{selectedLink?.customSlug || selectedLink?.shortCode}
              </div>
              <Button onClick={downloadQRCode} className="bg-primary hover:bg-primary/90 text-primary-foreground w-full">
                <Download className="h-4 w-4 mr-2" />
                Download QR Code
              </Button>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 border-4 border-transparent border-t-primary rounded-full mx-auto animate-spin"></div>
              <p className="mt-4 text-muted-foreground">Generating QR code...</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}