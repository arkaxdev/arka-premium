import { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { db } from "@/lib/db"
import bcrypt from "bcryptjs"

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
        twoFactorCode: { label: "2FA Code", type: "text", required: false }
      },
      async authorize(credentials) {
        console.log("Authorize function called with credentials:", credentials?.email)
        
        if (!credentials?.email || !credentials?.password) {
          console.log("Missing credentials")
          return null
        }

        const user = await db.user.findUnique({
          where: {
            email: credentials.email
          }
        })

        if (!user || !user.password) {
          console.log("User not found or no password")
          return null
        }

        const isPasswordValid = await bcrypt.compare(
          credentials.password,
          user.password
        )

        if (!isPasswordValid) {
          console.log("Invalid password")
          return null
        }

        console.log("Authentication successful for user:", user.email)
        console.log("User role:", user.role)

        // Update last login time
        await db.user.update({
          where: { id: user.id },
          data: { lastLoginAt: new Date() }
        })

        const userObj = {
          id: user.id,
          email: user.email,
          name: user.name || '',
          username: user.username || '',
          isVIP: user.isVIP || false,
          role: user.role as "ADMIN" | "VIP" | "FREE" || 'FREE',
          twoFactorEnabled: user.twoFactorEnabled || false
        }
        
        console.log("Returning user object:", userObj)
        return userObj
      }
    })
  ],
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  callbacks: {
    async jwt({ token, user }) {
      console.log("JWT callback - user exists:", !!user)
      if (user) {
        console.log("JWT callback - setting user data with role:", user.role)
        token.id = user.id
        token.email = user.email
        token.name = user.name
        token.username = user.username
        token.isVIP = user.isVIP
        token.role = user.role
        token.twoFactorEnabled = user.twoFactorEnabled
      }
      console.log("JWT token role:", token.role)
      return token
    },
    async session({ session, token }) {
      console.log("Session callback - token exists:", !!token)
      console.log("Session callback - token role:", token.role)
      if (token && session.user) {
        console.log("Session callback - setting session data")
        session.user.id = token.id as string
        session.user.email = token.email as string
        session.user.name = token.name as string
        session.user.username = token.username as string
        session.user.isVIP = token.isVIP as boolean
        session.user.role = token.role as "ADMIN" | "VIP" | "FREE"
        session.user.twoFactorEnabled = token.twoFactorEnabled as boolean
      }
      console.log("Final session user role:", session.user?.role)
      return session
    }
  },
  pages: {
    signIn: "/auth/signin"
  },
  secret: process.env.NEXTAUTH_SECRET,
}
