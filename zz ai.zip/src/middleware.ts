import { withAuth } from "next-auth/middleware"
import { NextResponse } from "next/server"

export default withAuth(
  function middleware(req) {
    // Allow the request to continue
    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        // Allow all requests for now to debug
        console.log("Middleware - Path:", req.nextUrl.pathname)
        console.log("Middleware - Token exists:", !!token)
        if (token) {
          console.log("Middleware - User role:", token.role)
        }
        
        // For admin routes, check if user has ADMIN role
        if (req.nextUrl.pathname.startsWith("/admin")) {
          return token?.role === "ADMIN"
        }
        
        // For other protected routes, just check if user is authenticated
        if (req.nextUrl.pathname.startsWith("/dashboard") || 
            req.nextUrl.pathname.startsWith("/api/links") ||
            req.nextUrl.pathname.startsWith("/api/admin")) {
          return !!token
        }
        
        // Allow all other routes
        return true
      }
    }
  }
)

// Configure which routes to protect
export const config = {
  matcher: [
    "/admin/:path*",
    "/dashboard/:path*",
    "/api/links/:path*",
    "/api/admin/:path*"
  ]
}
